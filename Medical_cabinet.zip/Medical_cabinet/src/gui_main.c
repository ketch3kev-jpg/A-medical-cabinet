#include "../include/scheduler.h"
#include "../include/patient.h"
#include "../include/doctor.h"
#include <gtk/gtk.h>
#include <time.h>

// Global variables
PatientLinkedList* global_patient_list = NULL;
Doctor global_doctor;
GtkWidget *main_window = NULL;
GtkWidget *patient_treeview = NULL;
GtkListStore *patient_liststore = NULL;
GtkWidget *edit_button, *delete_button;

// Function prototypes
void initialize_system();
void cleanup_system();
void create_sample_patients();
void refresh_patient_list();

// GTK GUI functions
void create_gui();
void on_add_patient_clicked(GtkButton *button, gpointer user_data);
void on_edit_patient_clicked(GtkButton *button, gpointer user_data);
void on_delete_patient_clicked(GtkButton *button, gpointer user_data);
void on_run_simulation_clicked(GtkButton *button, gpointer user_data);
void on_show_stats_clicked(GtkButton *button, gpointer user_data);
void on_treeview_selection_changed(GtkTreeSelection *selection, gpointer user_data);
void on_create_sample_clicked(GtkButton *button, gpointer user_data);
void on_doctor_status_clicked(GtkButton *button, gpointer user_data);

int main(int argc, char *argv[]) {
    printf("=== MEDICAL CABINET DOCTOR SCHEDULING SYSTEM ===\n");
    printf("=== (Re)Planification Module - GUI Version ===\n\n");

    // Initialize system
    initialize_system();

    // Start GTK GUI
    gtk_init(&argc, &argv);
    create_gui();
    gtk_main();

    // Cleanup
    cleanup_system();
    return 0;
}

void initialize_system() {
    // Initialize global patient list
    global_patient_list = createLinkedList();
    if (!global_patient_list) {
        printf("Error: Could not create patient list!\n");
        exit(1);
    }

    // Initialize doctor
    initialiseDoctor(&global_doctor, "Dr. Smith");
    
    printf("System initialized successfully.\n");
}

void cleanup_system() {
    if (global_patient_list) {
        // Free all patients and the list
        PatientNode* current = global_patient_list->head;
        while (current) {
            PatientNode* next = current->next;
            free(current->patient);
            free(current);
            current = next;
        }
        free(global_patient_list);
    }
    printf("System cleanup completed.\n");
}

void create_sample_patients() {
    printf("\n=== CREATING SAMPLE PATIENTS ===\n");
    
    // Clear existing list
    PatientNode* current = global_patient_list->head;
    while (current) {
        PatientNode* next = current->next;
        free(current->patient);
        free(current);
        current = next;
    }
    global_patient_list->head = NULL;
    global_patient_list->tail = NULL;
    global_patient_list->count = 0;

    // Sample patients (same as CLI version)
    Patient* patients[10];
    
    patients[0] = malloc(sizeof(Patient));
    initialisePatient(patients[0], 1, "John Emergency", URGENT, -1, 30, 15);
    
    patients[1] = malloc(sizeof(Patient));
    initialisePatient(patients[1], 2, "Maria Critical", URGENT, -1, 120, 20);
    
    patients[2] = malloc(sizeof(Patient));
    initialisePatient(patients[2], 3, "Robert Wilson", APPOINTMENT, 60, 55, 25);
    
    patients[3] = malloc(sizeof(Patient));
    initialisePatient(patients[3], 4, "Sarah Johnson", APPOINTMENT, 90, 85, 15);
    
    patients[4] = malloc(sizeof(Patient));
    initialisePatient(patients[4], 5, "Michael Brown", APPOINTMENT, 150, 160, 30);
    
    patients[5] = malloc(sizeof(Patient));
    initialisePatient(patients[5], 6, "Emily Davis", WALKIN, -1, 45, 10);
    
    patients[6] = malloc(sizeof(Patient));
    initialisePatient(patients[6], 7, "David Miller", WALKIN, -1, 100, 12);
    
    patients[7] = malloc(sizeof(Patient));
    initialisePatient(patients[7], 8, "Lisa Garcia", WALKIN, -1, 180, 8);
    
    patients[8] = malloc(sizeof(Patient));
    initialisePatient(patients[8], 9, "Thomas Lee", APPOINTMENT, 200, 195, 18);
    
    patients[9] = malloc(sizeof(Patient));
    initialisePatient(patients[9], 10, "Jennifer White", URGENT, -1, 240, 22);

    // Add to linked list
    for (int i = 0; i < 10; i++) {
        addPatientToLinkedList(global_patient_list, patients[i]);
    }

    printf("Created 10 sample patients\n");
}

void create_gui() {
    // Create main window
    main_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(main_window), "Medical Cabinet Scheduling System");
    gtk_window_set_default_size(GTK_WINDOW(main_window), 1000, 600);
    gtk_container_set_border_width(GTK_CONTAINER(main_window), 10);
    
    // Create main vertical box
    GtkWidget *vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_container_add(GTK_CONTAINER(main_window), vbox);
    
    // Create title
    GtkWidget *title_label = gtk_label_new("Medical Cabinet Doctor Scheduling System");
    PangoAttrList *attrs = pango_attr_list_new();
    pango_attr_list_insert(attrs, pango_attr_weight_new(PANGO_WEIGHT_BOLD));
    pango_attr_list_insert(attrs, pango_attr_scale_new(1.2));
    gtk_label_set_attributes(GTK_LABEL(title_label), attrs);
    gtk_box_pack_start(GTK_BOX(vbox), title_label, FALSE, FALSE, 0);
    
    // Create patient list treeview
    GtkWidget *scrolled_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled_window),
                                  GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_box_pack_start(GTK_BOX(vbox), scrolled_window, TRUE, TRUE, 0);
    
    // Create list store for patient data
    patient_liststore = gtk_list_store_new(7, 
        G_TYPE_INT,    // ID
        G_TYPE_STRING, // Name
        G_TYPE_STRING, // Type
        G_TYPE_STRING, // Arrival Time
        G_TYPE_STRING, // Scheduled Time
        G_TYPE_INT,    // Consultation Time
        G_TYPE_STRING  // State
    );
    
    patient_treeview = gtk_tree_view_new_with_model(GTK_TREE_MODEL(patient_liststore));
    gtk_container_add(GTK_CONTAINER(scrolled_window), patient_treeview);
    
    // Create columns
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("ID", renderer, "text", 0, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(patient_treeview), column);
    
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Name", renderer, "text", 1, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(patient_treeview), column);
    
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Type", renderer, "text", 2, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(patient_treeview), column);
    
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Arrival", renderer, "text", 3, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(patient_treeview), column);
    
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Scheduled", renderer, "text", 4, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(patient_treeview), column);
    
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Consultation", renderer, "text", 5, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(patient_treeview), column);
    
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("State", renderer, "text", 6, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(patient_treeview), column);
    
    // Create button box
    GtkWidget *button_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    gtk_box_pack_start(GTK_BOX(vbox), button_box, FALSE, FALSE, 0);
    
    // Create buttons
    GtkWidget *add_button = gtk_button_new_with_label("Add Patient");
    edit_button = gtk_button_new_with_label("Edit Patient");
    delete_button = gtk_button_new_with_label("Delete Patient");
    GtkWidget *sample_button = gtk_button_new_with_label("Create Sample");
    GtkWidget *simulate_button = gtk_button_new_with_label("Run Simulation");
    GtkWidget *stats_button = gtk_button_new_with_label("Show Statistics");
    GtkWidget *doctor_button = gtk_button_new_with_label("Doctor Status");
    
    gtk_box_pack_start(GTK_BOX(button_box), add_button, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(button_box), edit_button, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(button_box), delete_button, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(button_box), sample_button, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(button_box), simulate_button, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(button_box), stats_button, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(button_box), doctor_button, TRUE, TRUE, 0);
    
    // Initially disable edit and delete buttons
    gtk_widget_set_sensitive(edit_button, FALSE);
    gtk_widget_set_sensitive(delete_button, FALSE);
    
    // Connect signals
    g_signal_connect(add_button, "clicked", G_CALLBACK(on_add_patient_clicked), NULL);
    g_signal_connect(edit_button, "clicked", G_CALLBACK(on_edit_patient_clicked), NULL);
    g_signal_connect(delete_button, "clicked", G_CALLBACK(on_delete_patient_clicked), NULL);
    g_signal_connect(simulate_button, "clicked", G_CALLBACK(on_run_simulation_clicked), NULL);
    g_signal_connect(stats_button, "clicked", G_CALLBACK(on_show_stats_clicked), NULL);
    g_signal_connect(main_window, "destroy", G_CALLBACK(gtk_main_quit), NULL);
    
    g_signal_connect(sample_button, "clicked", G_CALLBACK(on_create_sample_clicked), NULL);
    g_signal_connect(doctor_button, "clicked", G_CALLBACK(on_doctor_status_clicked), NULL);
    
    // Connect selection changed signal
    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(patient_treeview));
    g_signal_connect(selection, "changed", G_CALLBACK(on_treeview_selection_changed), NULL);
    
    // Refresh patient list
    refresh_patient_list();
    
    // Show all widgets
    gtk_widget_show_all(main_window);
}

void refresh_patient_list() {
    gtk_list_store_clear(patient_liststore);
    
    PatientNode* current = global_patient_list->head;
    while (current) {
        Patient* p = current->patient;
        
        GtkTreeIter iter;
        gtk_list_store_append(patient_liststore, &iter);
        gtk_list_store_set(patient_liststore, &iter,
            0, p->id,
            1, p->name,
            2, patientTypeToString(p->type),
            3, patientTimeToString(p->arrivalTime),
            4, p->scheduledTime >= 0 ? patientTimeToString(p->scheduledTime) : "N/A",
            5, p->consultationTime,
            6, PStateToString(p->state),
            -1);
        
        current = current->next;
    }
}

// GTK Signal handlers
void on_add_patient_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *dialog, *content_area, *grid;
    GtkWidget *id_entry, *name_entry, *type_combo, *arrival_hour, *arrival_minute;
    GtkWidget *scheduled_hour, *scheduled_minute, *consultation_entry;
    GtkWidget *scheduled_label, *scheduled_box;
    
    dialog = gtk_dialog_new_with_buttons("Add New Patient",
                                        GTK_WINDOW(main_window),
                                        GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
                                        "Add",
                                        GTK_RESPONSE_ACCEPT,
                                        "Cancel",
                                        GTK_RESPONSE_REJECT,
                                        NULL);
    
    content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grid), 5);
    gtk_grid_set_column_spacing(GTK_GRID(grid), 5);
    gtk_container_set_border_width(GTK_CONTAINER(grid), 10);
    gtk_container_add(GTK_CONTAINER(content_area), grid);
    
    // Create form fields
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Patient ID:"), 0, 0, 1, 1);
    id_entry = gtk_entry_new();
    gtk_grid_attach(GTK_GRID(grid), id_entry, 1, 0, 1, 1);
    
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Name:"), 0, 1, 1, 1);
    name_entry = gtk_entry_new();
    gtk_grid_attach(GTK_GRID(grid), name_entry, 1, 1, 1, 1);
    
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Type:"), 0, 2, 1, 1);
    type_combo = gtk_combo_box_text_new();
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(type_combo), "Urgent");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(type_combo), "Appointment");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(type_combo), "Walk-in");
    gtk_combo_box_set_active(GTK_COMBO_BOX(type_combo), 0);
    gtk_grid_attach(GTK_GRID(grid), type_combo, 1, 2, 1, 1);
    
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Arrival Time:"), 0, 3, 1, 1);
    GtkWidget *arrival_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    arrival_hour = gtk_spin_button_new_with_range(8, 18, 1);
    arrival_minute = gtk_spin_button_new_with_range(0, 59, 1);
    gtk_box_pack_start(GTK_BOX(arrival_box), gtk_label_new("HH:"), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(arrival_box), arrival_hour, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(arrival_box), gtk_label_new("MM:"), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(arrival_box), arrival_minute, FALSE, FALSE, 0);
    gtk_grid_attach(GTK_GRID(grid), arrival_box, 1, 3, 1, 1);
    
    scheduled_label = gtk_label_new("Scheduled Time:");
    scheduled_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    scheduled_hour = gtk_spin_button_new_with_range(8, 18, 1);
    scheduled_minute = gtk_spin_button_new_with_range(0, 59, 1);
    gtk_box_pack_start(GTK_BOX(scheduled_box), gtk_label_new("HH:"), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(scheduled_box), scheduled_hour, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(scheduled_box), gtk_label_new("MM:"), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(scheduled_box), scheduled_minute, FALSE, FALSE, 0);
    
    gtk_grid_attach(GTK_GRID(grid), scheduled_label, 0, 4, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), scheduled_box, 1, 4, 1, 1);
    
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Consultation Time (min):"), 0, 5, 1, 1);
    consultation_entry = gtk_spin_button_new_with_range(1, 120, 1);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(consultation_entry), 15);
    gtk_grid_attach(GTK_GRID(grid), consultation_entry, 1, 5, 1, 1);
    
    // Show/hide scheduled time based on patient type
    g_signal_connect(type_combo, "changed", G_CALLBACK(on_type_combo_changed), 
                     scheduled_label, scheduled_box);
    
    gtk_widget_show_all(dialog);
    
    gint result = gtk_dialog_run(GTK_DIALOG(dialog));
    
    if (result == GTK_RESPONSE_ACCEPT) {
        // Get values from form
        int id = atoi(gtk_entry_get_text(GTK_ENTRY(id_entry)));
        const char* name = gtk_entry_get_text(GTK_ENTRY(name_entry));
        int type_index = gtk_combo_box_get_active(GTK_COMBO_BOX(type_combo));
        int arrival_h = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(arrival_hour));
        int arrival_m = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(arrival_minute));
        int scheduled_h = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(scheduled_hour));
        int scheduled_m = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(scheduled_minute));
        int consultation = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(consultation_entry));
        
        // Convert to AppointmentType
        AppointmentType type;
        switch(type_index) {
            case 0: type = URGENT; break;
            case 1: type = APPOINTMENT; break;
            case 2: type = WALKIN; break;
            default: type = WALKIN;
        }
        
        // Convert times to minutes from 8:00
        int arrival_time = (arrival_h - 8) * 60 + arrival_m;
        int scheduled_time = (type == APPOINTMENT) ? ((scheduled_h - 8) * 60 + scheduled_m) : -1;
        
        // Check if ID already exists
        if (findPatientInLinkedList(global_patient_list, id)) {
            GtkWidget *error_dialog = gtk_message_dialog_new(GTK_WINDOW(main_window),
                GTK_DIALOG_DESTROY_WITH_PARENT,
                GTK_MESSAGE_ERROR,
                GTK_BUTTONS_OK,
                "Patient ID %d already exists!", id);
            gtk_dialog_run(GTK_DIALOG(error_dialog));
            gtk_widget_destroy(error_dialog);
        } else {
            // Create and add patient
            Patient* new_patient = malloc(sizeof(Patient));
            initialisePatient(new_patient, id, name, type, scheduled_time, arrival_time, consultation);
            addPatientToLinkedList(global_patient_list, new_patient);
            
            refresh_patient_list();
            
            GtkWidget *message_dialog = gtk_message_dialog_new(GTK_WINDOW(main_window),
                GTK_DIALOG_DESTROY_WITH_PARENT,
                GTK_MESSAGE_INFO,
                GTK_BUTTONS_OK,
                "Patient added successfully!");
            gtk_dialog_run(GTK_DIALOG(message_dialog));
            gtk_widget_destroy(message_dialog);
        }
    }
    
    gtk_widget_destroy(dialog);
}

void on_type_combo_changed(GtkComboBox *combo, gpointer user_data) {
    int type_index = gtk_combo_box_get_active(combo);
    GtkWidget *scheduled_label = ((GtkWidget**)user_data)[0];
    GtkWidget *scheduled_box = ((GtkWidget**)user_data)[1];
    
    // Show scheduled time only for appointments
    if (type_index == 1) { // Appointment
        gtk_widget_show(scheduled_label);
        gtk_widget_show(scheduled_box);
    } else {
        gtk_widget_hide(scheduled_label);
        gtk_widget_hide(scheduled_box);
    }
}

void on_edit_patient_clicked(GtkButton *button, gpointer user_data) {
    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(patient_treeview));
    GtkTreeModel *model;
    GtkTreeIter iter;
    
    if (gtk_tree_selection_get_selected(selection, &model, &iter)) {
        gint id;
        gchar *name, *type_str, *arrival_str, *scheduled_str;
        gint consultation;
        
        gtk_tree_model_get(model, &iter, 
                          0, &id,
                          1, &name,
                          2, &type_str,
                          3, &arrival_str,
                          4, &scheduled_str,
                          5, &consultation,
                          -1);
        
        // Find the patient
        Patient* patient = findPatientInLinkedList(global_patient_list, id);
        if (patient) {
            // Create edit dialog (similar to add dialog but pre-filled)
            GtkWidget *dialog, *content_area, *grid;
            GtkWidget *name_entry, *type_combo, *arrival_hour, *arrival_minute;
            GtkWidget *scheduled_hour, *scheduled_minute, *consultation_entry;
            
            dialog = gtk_dialog_new_with_buttons("Edit Patient",
                                                GTK_WINDOW(main_window),
                                                GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
                                                "Save",
                                                GTK_RESPONSE_ACCEPT,
                                                "Cancel",
                                                GTK_RESPONSE_REJECT,
                                                NULL);
            
            content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
            grid = gtk_grid_new();
            gtk_grid_set_row_spacing(GTK_GRID(grid), 5);
            gtk_grid_set_column_spacing(GTK_GRID(grid), 5);
            gtk_container_set_border_width(GTK_CONTAINER(grid), 10);
            gtk_container_add(GTK_CONTAINER(content_area), grid);
            
            // ID (read-only)
            gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Patient ID:"), 0, 0, 1, 1);
            GtkWidget *id_label = gtk_label_new(g_strdup_printf("%d", id));
            gtk_grid_attach(GTK_GRID(grid), id_label, 1, 0, 1, 1);
            
            // Name
            gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Name:"), 0, 1, 1, 1);
            name_entry = gtk_entry_new();
            gtk_entry_set_text(GTK_ENTRY(name_entry), name);
            gtk_grid_attach(GTK_GRID(grid), name_entry, 1, 1, 1, 1);
            
            // Type
            gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Type:"), 0, 2, 1, 1);
            type_combo = gtk_combo_box_text_new();
            gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(type_combo), "Urgent");
            gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(type_combo), "Appointment");
            gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(type_combo), "Walk-in");
            
            // Set current type
            if (strcmp(type_str, "Urgent") == 0)
                gtk_combo_box_set_active(GTK_COMBO_BOX(type_combo), 0);
            else if (strcmp(type_str, "Appointment") == 0)
                gtk_combo_box_set_active(GTK_COMBO_BOX(type_combo), 1);
            else
                gtk_combo_box_set_active(GTK_COMBO_BOX(type_combo), 2);
                
            gtk_grid_attach(GTK_GRID(grid), type_combo, 1, 2, 1, 1);
            
            // Parse and set current times
            int arrival_h, arrival_m, scheduled_h, scheduled_m;
            sscanf(arrival_str, "%d:%d", &arrival_h, &arrival_m);
            
            gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Arrival Time:"), 0, 3, 1, 1);
            GtkWidget *arrival_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
            arrival_hour = gtk_spin_button_new_with_range(8, 18, 1);
            arrival_minute = gtk_spin_button_new_with_range(0, 59, 1);
            gtk_spin_button_set_value(GTK_SPIN_BUTTON(arrival_hour), arrival_h);
            gtk_spin_button_set_value(GTK_SPIN_BUTTON(arrival_minute), arrival_m);
            gtk_box_pack_start(GTK_BOX(arrival_box), gtk_label_new("HH:"), FALSE, FALSE, 0);
            gtk_box_pack_start(GTK_BOX(arrival_box), arrival_hour, FALSE, FALSE, 0);
            gtk_box_pack_start(GTK_BOX(arrival_box), gtk_label_new("MM:"), FALSE, FALSE, 0);
            gtk_box_pack_start(GTK_BOX(arrival_box), arrival_minute, FALSE, FALSE, 0);
            gtk_grid_attach(GTK_GRID(grid), arrival_box, 1, 3, 1, 1);
            
            // Scheduled time (only for appointments)
            if (strcmp(type_str, "Appointment") == 0 && strcmp(scheduled_str, "N/A") != 0) {
                sscanf(scheduled_str, "%d:%d", &scheduled_h, &scheduled_m);
                
                gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Scheduled Time:"), 0, 4, 1, 1);
                GtkWidget *scheduled_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
                scheduled_hour = gtk_spin_button_new_with_range(8, 18, 1);
                scheduled_minute = gtk_spin_button_new_with_range(0, 59, 1);
                gtk_spin_button_set_value(GTK_SPIN_BUTTON(scheduled_hour), scheduled_h);
                gtk_spin_button_set_value(GTK_SPIN_BUTTON(scheduled_minute), scheduled_m);
                gtk_box_pack_start(GTK_BOX(scheduled_box), gtk_label_new("HH:"), FALSE, FALSE, 0);
                gtk_box_pack_start(GTK_BOX(scheduled_box), scheduled_hour, FALSE, FALSE, 0);
                gtk_box_pack_start(GTK_BOX(scheduled_box), gtk_label_new("MM:"), FALSE, FALSE, 0);
                gtk_box_pack_start(GTK_BOX(scheduled_box), scheduled_minute, FALSE, FALSE, 0);
                gtk_grid_attach(GTK_GRID(grid), scheduled_box, 1, 4, 1, 1);
            }
            
            // Consultation time
            gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Consultation Time (min):"), 0, 5, 1, 1);
            consultation_entry = gtk_spin_button_new_with_range(1, 120, 1);
            gtk_spin_button_set_value(GTK_SPIN_BUTTON(consultation_entry), consultation);
            gtk_grid_attach(GTK_GRID(grid), consultation_entry, 1, 5, 1, 1);
            
            gtk_widget_show_all(dialog);
            
            gint result = gtk_dialog_run(GTK_DIALOG(dialog));
            
            if (result == GTK_RESPONSE_ACCEPT) {
                // Update patient data
                strncpy(patient->name, gtk_entry_get_text(GTK_ENTRY(name_entry)), sizeof(patient->name) - 1);
                
                int type_index = gtk_combo_box_get_active(GTK_COMBO_BOX(type_combo));
                switch(type_index) {
                    case 0: patient->type = URGENT; break;
                    case 1: patient->type = APPOINTMENT; break;
                    case 2: patient->type = WALKIN; break;
                }
                
                int new_arrival_h = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(arrival_hour));
                int new_arrival_m = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(arrival_minute));
                patient->arrivalTime = (new_arrival_h - 8) * 60 + new_arrival_m;
                
                if (patient->type == APPOINTMENT) {
                    int new_scheduled_h = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(scheduled_hour));
                    int new_scheduled_m = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(scheduled_minute));
                    patient->scheduledTime = (new_scheduled_h - 8) * 60 + new_scheduled_m;
                } else {
                    patient->scheduledTime = -1;
                }
                
                patient->consultationTime = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(consultation_entry));
                
                refresh_patient_list();
                
                GtkWidget *message_dialog = gtk_message_dialog_new(GTK_WINDOW(main_window),
                    GTK_DIALOG_DESTROY_WITH_PARENT,
                    GTK_MESSAGE_INFO,
                    GTK_BUTTONS_OK,
                    "Patient updated successfully!");
                gtk_dialog_run(GTK_DIALOG(message_dialog));
                gtk_widget_destroy(message_dialog);
            }
            
            gtk_widget_destroy(dialog);
        }
        
        // Free allocated strings
        g_free(name);
        g_free(type_str);
        g_free(arrival_str);
        g_free(scheduled_str);
    } else {
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(main_window),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_WARNING,
            GTK_BUTTONS_OK,
            "Please select a patient to edit.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    }
}

void on_delete_patient_clicked(GtkButton *button, gpointer user_data) {
    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(patient_treeview));
    GtkTreeModel *model;
    GtkTreeIter iter;
    
    if (gtk_tree_selection_get_selected(selection, &model, &iter)) {
        gint id;
        gchar *name;
        gtk_tree_model_get(model, &iter, 0, &id, 1, &name, -1);
        
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(main_window),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_QUESTION,
            GTK_BUTTONS_YES_NO,
            "Are you sure you want to delete patient '%s' (ID: %d)?", name, id);
        
        gint result = gtk_dialog_run(GTK_DIALOG(dialog));
        if (result == GTK_RESPONSE_YES) {
            Patient* patient = findPatientInLinkedList(global_patient_list, id);
            if (patient) {
                removePatientFromLinkedList(global_patient_list, id);
                free(patient);
                refresh_patient_list();
                
                GtkWidget *message_dialog = gtk_message_dialog_new(GTK_WINDOW(main_window),
                    GTK_DIALOG_DESTROY_WITH_PARENT,
                    GTK_MESSAGE_INFO,
                    GTK_BUTTONS_OK,
                    "Patient deleted successfully!");
                gtk_dialog_run(GTK_DIALOG(message_dialog));
                gtk_widget_destroy(message_dialog);
            }
        }
        
        gtk_widget_destroy(dialog);
        g_free(name);
    } else {
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(main_window),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_WARNING,
            GTK_BUTTONS_OK,
            "Please select a patient to delete.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    }
}

void on_run_simulation_clicked(GtkButton *button, gpointer user_data) {
    if (global_patient_list->count == 0) {
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(main_window),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_WARNING,
            GTK_BUTTONS_OK,
            "No patients available for simulation!");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }
    
    GtkWidget *dialog, *content_area, *combo;
    GtkWidget *vbox, *label;
    
    dialog = gtk_dialog_new_with_buttons("Run Simulation",
                                        GTK_WINDOW(main_window),
                                        GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
                                        "Run",
                                        GTK_RESPONSE_ACCEPT,
                                        "Cancel",
                                        GTK_RESPONSE_REJECT,
                                        NULL);
    
    content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_container_set_border_width(GTK_CONTAINER(vbox), 10);
    gtk_container_add(GTK_CONTAINER(content_area), vbox);
    
    label = gtk_label_new("Select scheduling algorithm:");
    gtk_box_pack_start(GTK_BOX(vbox), label, FALSE, FALSE, 0);
    
    combo = gtk_combo_box_text_new();
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(combo), "First-Come-First-Served (FCFS)");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(combo), "Shortest Job First (SJF)");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(combo), "Round Robin");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(combo), "Priority Scheduling");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(combo), "Hybrid Scheduler (Recommended)");
    gtk_combo_box_set_active(GTK_COMBO_BOX(combo), 4);
    gtk_box_pack_start(GTK_BOX(vbox), combo, FALSE, FALSE, 0);
    
    gtk_widget_show_all(dialog);
    
    gint result = gtk_dialog_run(GTK_DIALOG(dialog));
    
    if (result == GTK_RESPONSE_ACCEPT) {
        int algorithm_choice = gtk_combo_box_get_active(GTK_COMBO_BOX(combo)) + 1;
        
        // Reset doctor for new simulation
        initialiseDoctor(&global_doctor, global_doctor.name);
        
        // Reset all patients
        PatientNode* current = global_patient_list->head;
        while (current) {
            resetPatientScheduling(current->patient);
            current = current->next;
        }
        
        // Run simulation
        clock_t start = clock();
        
        switch(algorithm_choice) {
            case 1:
                runFCFS(global_patient_list, &global_doctor);
                break;
            case 2:
                runSJF(global_patient_list, &global_doctor);
                break;
            case 3:
                runRoundRobin(global_patient_list, &global_doctor);
                break;
            case 4:
                runPriorityScheduling(global_patient_list, &global_doctor);
                break;
            case 5:
                SectionedWaitingList* sectionedList = divideByDynamicPriority(global_patient_list, 0);
                if (sectionedList) {
                    runHybridScheduler(sectionedList, &global_doctor);
                    freeSectionedList(sectionedList);
                }
                break;
        }
        
        clock_t end = clock();
        double simulationTime = ((double)(end - start)) / CLOCKS_PER_SEC;
        
        refresh_patient_list();
        
        GtkWidget *message_dialog = gtk_message_dialog_new(GTK_WINDOW(main_window),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_INFO,
            GTK_BUTTONS_OK,
            "Simulation completed in %.2f seconds!\nTotal time: %s to %s",
            simulationTime,
            minutesToTime(global_doctor.startTime),
            minutesToTime(global_doctor.currentTime));
        gtk_dialog_run(GTK_DIALOG(message_dialog));
        gtk_widget_destroy(message_dialog);
    }
    
    gtk_widget_destroy(dialog);
}

void on_show_stats_clicked(GtkButton *button, gpointer user_data) {
    if (global_patient_list->count == 0) {
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(main_window),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_WARNING,
            GTK_BUTTONS_OK,
            "No patients available for statistics!");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }
    
    // Create statistics dialog
    GtkWidget *dialog, *content_area, *scrolled_window, *text_view;
    GtkTextBuffer *buffer;
    
    dialog = gtk_dialog_new_with_buttons("Scheduling Statistics",
                                        GTK_WINDOW(main_window),
                                        GTK_DIALOG_DESTROY_WITH_PARENT,
                                        "Close",
                                        GTK_RESPONSE_CLOSE,
                                        NULL);
    
    content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    scrolled_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled_window),
                                  GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_container_set_border_width(GTK_CONTAINER(scrolled_window), 10);
    gtk_container_add(GTK_CONTAINER(content_area), scrolled_window);
    
    text_view = gtk_text_view_new();
    gtk_text_view_set_editable(GTK_TEXT_VIEW(text_view), FALSE);
    gtk_text_view_set_wrap_mode(GTK_TEXT_VIEW(text_view), GTK_WRAP_WORD);
    gtk_container_add(GTK_CONTAINER(scrolled_window), text_view);
    
    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(text_view));
    
    // Generate statistics text
    GString *stats_text = g_string_new("");
    
    QueueData stats;
    calculateLinkedListStatistics(global_patient_list, &stats);
    
    g_string_append_printf(stats_text, "=== SCHEDULING STATISTICS ===\n\n");
    g_string_append_printf(stats_text, "Patient Distribution:\n");
    g_string_append_printf(stats_text, "- Total Patients: %d\n", stats.numPatient);
    g_string_append_printf(stats_text, "- Urgent Cases: %d\n", stats.urgentCount);
    g_string_append_printf(stats_text, "- Appointments: %d (Late: %d)\n", stats.appointmentCount, stats.lateAppointments);
    g_string_append_printf(stats_text, "- Walk-ins: %d (Promoted: %d)\n", stats.walkinCount, stats.promotedWalkins);
    g_string_append_printf(stats_text, "- Maximum Waiting Time: %d minutes\n", stats.maxWaitingTime);
    g_string_append_printf(stats_text, "- Maximum Walk-in Waiting: %d minutes\n\n", stats.maxWalkinWaiting);
    
    // Calculate averages
    int totalWaiting = 0;
    int totalTurnaround = 0;
    int completedPatients = 0;
    
    PatientNode* current = global_patient_list->head;
    while (current) {
        if (current->patient->state == COMPLETED) {
            totalWaiting += current->patient->waitingTime;
            totalTurnaround += current->patient->turnaroundTime;
            completedPatients++;
        }
        current = current->next;
    }
    
    if (completedPatients > 0) {
        g_string_append_printf(stats_text, "Performance Metrics:\n");
        g_string_append_printf(stats_text, "- Average Waiting Time: %.2f minutes\n", (float)totalWaiting / completedPatients);
        g_string_append_printf(stats_text, "- Average Turnaround Time: %.2f minutes\n", (float)totalTurnaround / completedPatients);
        
        // Doctor utilization
        int totalTime = global_doctor.currentTime - global_doctor.startTime;
        if (totalTime > 0) {
            float utilization = (global_doctor.totalConsultationTime * 100.0) / totalTime;
            g_string_append_printf(stats_text, "- Doctor Utilization: %.2f%%\n\n", utilization);
        }
    }
    
    g_string_append_printf(stats_text, "Doctor Performance:\n");
    g_string_append_printf(stats_text, "- Patients Seen: %d\n", global_doctor.patientsSeen);
    g_string_append_printf(stats_text, "- Urgent Patients: %d\n", global_doctor.urgentPatientsSeen);
    g_string_append_printf(stats_text, "- Breaks Taken: %d\n", global_doctor.breaksTaken);
    g_string_append_printf(stats_text, "- Breaks Skipped: %d\n", global_doctor.breaksSkippedDueToUrgent);
    
    gtk_text_buffer_set_text(buffer, stats_text->str, -1);
    g_string_free(stats_text, TRUE);
    
    gtk_widget_show_all(dialog);
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);
}

void on_treeview_selection_changed(GtkTreeSelection *selection, gpointer user_data) {
    GtkTreeModel *model;
    GtkTreeIter iter;
    
    if (gtk_tree_selection_get_selected(selection, &model, &iter)) {
        // Enable edit and delete buttons when a patient is selected
        gtk_widget_set_sensitive(edit_button, TRUE);
        gtk_widget_set_sensitive(delete_button, TRUE);
    } else {
        // Disable buttons when no patient is selected
        gtk_widget_set_sensitive(edit_button, FALSE);
        gtk_widget_set_sensitive(delete_button, FALSE);
    }
}

void on_create_sample_clicked(GtkButton *button, gpointer user_data) {
    create_sample_patients();
    refresh_patient_list();
    
    GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(main_window),
        GTK_DIALOG_DESTROY_WITH_PARENT,
        GTK_MESSAGE_INFO,
        GTK_BUTTONS_OK,
        "Sample patients created successfully!");
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);
}

void on_doctor_status_clicked(GtkButton *button, gpointer user_data) {
    // Create doctor status dialog
    GtkWidget *dialog, *content_area, *scrolled_window, *text_view;
    GtkTextBuffer *buffer;
    
    dialog = gtk_dialog_new_with_buttons("Doctor Status",
                                        GTK_WINDOW(main_window),
                                        GTK_DIALOG_DESTROY_WITH_PARENT,
                                        "Close",
                                        GTK_RESPONSE_CLOSE,
                                        NULL);
    
    content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    scrolled_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled_window),
                                  GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_container_set_border_width(GTK_CONTAINER(scrolled_window), 10);
    gtk_container_add(GTK_CONTAINER(content_area), scrolled_window);
    
    text_view = gtk_text_view_new();
    gtk_text_view_set_editable(GTK_TEXT_VIEW(text_view), FALSE);
    gtk_text_view_set_wrap_mode(GTK_TEXT_VIEW(text_view), GTK_WRAP_WORD);
    gtk_container_add(GTK_CONTAINER(scrolled_window), text_view);
    
    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(text_view));
    
    // Generate doctor status text
    GString *status_text = g_string_new("");
    
    g_string_append_printf(status_text, "=== DOCTOR STATUS ===\n\n");
    g_string_append_printf(status_text, "Name: %s\n", global_doctor.name);
    g_string_append_printf(status_text, "Current Time: %s\n", minutesToTime(global_doctor.currentTime));
    g_string_append_printf(status_text, "Working Hours: %s to %s\n", 
                          minutesToTime(global_doctor.startTime), 
                          minutesToTime(global_doctor.endTime));
    g_string_append_printf(status_text, "Break Schedule: %s to %s\n", 
                          minutesToTime(global_doctor.breakStart), 
                          minutesToTime(global_doctor.breakEnd));
    g_string_append_printf(status_text, "Currently With Urgent Patient: %s\n", 
                          global_doctor.isWithUrgentPatient ? "Yes" : "No");
    g_string_append_printf(status_text, "Currently On Break: %s\n", 
                          global_doctor.isOnBreak ? "Yes" : "No");
    g_string_append_printf(status_text, "Patients Seen Today: %d\n", global_doctor.patientsSeen);
    g_string_append_printf(status_text, "Urgent Patients Seen: %d\n", global_doctor.urgentPatientsSeen);
    g_string_append_printf(status_text, "Total Consultation Time: %d minutes\n", global_doctor.totalConsultationTime);
    g_string_append_printf(status_text, "Breaks Taken: %d\n", global_doctor.breaksTaken);
    g_string_append_printf(status_text, "Breaks Skipped Due to Urgent: %d\n", global_doctor.breaksSkippedDueToUrgent);
    g_string_append_printf(status_text, "Available: %s\n", 
                          isDoctorAvailable(&global_doctor, global_doctor.currentTime) ? "Yes" : "No");
    
    gtk_text_buffer_set_text(buffer, status_text->str, -1);
    g_string_free(status_text, TRUE);
    
    gtk_widget_show_all(dialog);
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);
}