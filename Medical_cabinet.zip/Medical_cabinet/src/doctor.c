#include "../include/doctor.h"

// Initialize doctor with basic information
void initialiseDoctor(Doctor* doctor, const char* name) {
    strncpy(doctor->name, name, sizeof(doctor->name) - 1);
    
    // Default schedule: 8:00 AM to 7:00 PM with 1 hour break at 12:00-1:00 PM
    setDoctorSchedule(doctor, 8, 0, 19, 0, 12, 0, 60);
    
    doctor->gapBetweenPatients = 1; // 1 minute between patients
    doctor->isOnBreak = 0;
    doctor->isWithUrgentPatient = 0;
    doctor->currentTime = doctor->startTime;
    doctor->patientsSeen = 0;
    doctor->totalConsultationTime = 0;
    doctor->urgentPatientsSeen = 0;
    doctor->breaksTaken = 0;
    doctor->breaksSkippedDueToUrgent = 0;
}

// Set doctor's schedule
void setDoctorSchedule(Doctor* doctor, int startHour, int startMinute, 
                      int endHour, int endMinute, int breakStartHour, 
                      int breakStartMinute, int breakDuration) {
    doctor->startTime = timeToMinutes(startHour, startMinute);
    doctor->endTime = timeToMinutes(endHour, endMinute);
    doctor->breakStart = timeToMinutes(breakStartHour, breakStartMinute);
    doctor->breakEnd = doctor->breakStart + breakDuration;
}

// Check if doctor is available at given time (considering breaks and urgent cases)
int isDoctorAvailable(const Doctor* doctor, int currentTime) {
    // Check if outside working hours
    if (currentTime < doctor->startTime || currentTime >= doctor->endTime) {
        return 0;
    }
    
    // Check if during break AND not with urgent patient
    if (doctor->isOnBreak && !doctor->isWithUrgentPatient) {
        return 0;
    }
    
    // If it's break time but doctor is with urgent patient, they're available
    if (currentTime >= doctor->breakStart && currentTime < doctor->breakEnd) {
        if (doctor->isWithUrgentPatient) {
            return 1; // Available because with urgent patient
        } else {
            return 0; // On break
        }
    }
    
    return 1;
}

// Get next available time considering breaks, working hours, and urgent cases
int getNextAvailableTime(Doctor* doctor, int currentTime, int isUrgentCase) {
    // If before start time, return start time
    if (currentTime < doctor->startTime) {
        return doctor->startTime;
    }
    
    // Check if we're at break time
    if (currentTime >= doctor->breakStart && currentTime < doctor->breakEnd) {
        if (isUrgentCase) {
            // Urgent case - doctor will skip break
            doctor->breaksSkippedDueToUrgent++;
            printf("  -> Doctor skipping break for urgent case at %s\n", minutesToTime(currentTime));
            return currentTime; // Available now for urgent case
        } else {
            // Non-urgent case - wait until break ends
            printf("  -> Doctor on break until %s\n", minutesToTime(doctor->breakEnd));
            return doctor->breakEnd;
        }
    }
    
    // If after end time, return next day start (for simulation completeness)
    if (currentTime >= doctor->endTime) {
        return doctor->startTime + 1440; // Next day
    }
    
    return currentTime;
}

// Check if it's time to take a break and take it if possible
void checkAndTakeBreak(Doctor* doctor, int currentTime) {
    // Only take break if not with urgent patient and it's break time
    if (!doctor->isWithUrgentPatient && 
        currentTime >= doctor->breakStart && 
        currentTime < doctor->breakEnd &&
        !doctor->isOnBreak) {
        
        doctor->isOnBreak = 1;
        doctor->breaksTaken++;
        printf("  -> Doctor taking break from %s to %s\n", 
               minutesToTime(currentTime), minutesToTime(doctor->breakEnd));
    }
    
    // End break if break time is over
    if (doctor->isOnBreak && currentTime >= doctor->breakEnd) {
        doctor->isOnBreak = 0;
        printf("  -> Doctor returning from break at %s\n", minutesToTime(currentTime));
    }
}

// Update doctor's time after a consultation
void updateDoctorTime(Doctor* doctor, int consultationTime, int isUrgentCase) {
    // Update urgent patient status
    doctor->isWithUrgentPatient = isUrgentCase;
    
    // Update time and statistics
    doctor->currentTime += consultationTime + doctor->gapBetweenPatients;
    doctor->patientsSeen++;
    doctor->totalConsultationTime += consultationTime;
    
    if (isUrgentCase) {
        doctor->urgentPatientsSeen++;
    }
    
    // Check if we should take a break after this consultation
    checkAndTakeBreak(doctor, doctor->currentTime);
    
    // Ensure we don't exceed end time
    if (doctor->currentTime > doctor->endTime) {
        doctor->currentTime = doctor->endTime;
    }
}

// Display doctor's current status
void displayDoctorStatus(const Doctor* doctor) {
    printf("\n=== Doctor Status ===\n");
    printf("Name: %s\n", doctor->name);
    printf("Current Time: %s\n", minutesToTime(doctor->currentTime));
    printf("Working Hours: %s to %s\n", 
           minutesToTime(doctor->startTime), minutesToTime(doctor->endTime));
    printf("Break Schedule: %s to %s\n", 
           minutesToTime(doctor->breakStart), minutesToTime(doctor->breakEnd));
    printf("Currently With Urgent Patient: %s\n", doctor->isWithUrgentPatient ? "Yes" : "No");
    printf("Currently On Break: %s\n", doctor->isOnBreak ? "Yes" : "No");
    printf("Patients Seen Today: %d\n", doctor->patientsSeen);
    printf("Urgent Patients Seen: %d\n", doctor->urgentPatientsSeen);
    printf("Total Consultation Time: %d minutes\n", doctor->totalConsultationTime);
    printf("Breaks Taken: %d\n", doctor->breaksTaken);
    printf("Breaks Skipped Due to Urgent: %d\n", doctor->breaksSkippedDueToUrgent);
    printf("Available: %s\n", isDoctorAvailable(doctor, doctor->currentTime) ? "Yes" : "No");
    printf("====================\n");
}

// Convert hours and minutes to total minutes from midnight
int timeToMinutes(int hours, int minutes) {
    return hours * 60 + minutes;
}

// Convert minutes to time string (HH:MM format)
char* minutesToTime(int minutes) {
    static char timeStr[10];
    int hours = minutes / 60;
    int mins = minutes % 60;
    snprintf(timeStr, sizeof(timeStr), "%02d:%02d", hours, mins);
    return timeStr;
}