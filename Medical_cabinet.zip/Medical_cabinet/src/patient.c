#include "../include/patient.h"

//converting the appointment types to strings
char* patientTypeToString(AppointmentType type){
    switch(type){
        case URGENT: return "Urgent";
        case APPOINTMENT: return "Appointment";
        case WALKIN: return "Walk-in";
        default: return "Unknown";
    }
}

//converting the process states to string
char* PStateToString(PState state){
    switch (state)
    {
    case WAITING: return "waiting";
    case IN_CONSULTATION: return "in-consultation";
    case COMPLETED: return "completed";
    case CANCELED: return "canceled";
    default: return "Unknown";
    }
}

//converting from a string to the enumeration AppointmentType
AppointmentType stringToPatientType(const char* typeStr){
    if(strcasecmp(typeStr, "urgent")==0) return URGENT;
    else if(strcasecmp(typeStr, "appointment")) return APPOINTMENT;
    else if(strcasecmp(typeStr, "walkin")) return WALKIN;
    else return WALKIN;
}

//converting time in minutes to a hour-minute format
char* patientTimeToString(int minutes){
    static char timeStr[10];
    if(minutes < 0){
        strcpy(timeStr, "NAT"); // "NAT" for "not a time"
        return timeStr;
    }

    int hours = minutes / 60 + 8;
    int mins = minutes % 60;
    snprintf(timeStr, sizeof(timeStr), "%02d:%02d", hours, mins);
    return timeStr;
}

void initialisePatient(Patient* patient, int id, const char* name,
        AppointmentType type, int scheduledTime, int arrivalTime, int consulationTime){
    //normal info
    patient->id = id;
    strncpy(patient->name, name, sizeof(patient->name));
    patient->name [sizeof(patient->name) -1] = '\0';

    //details
    patient->type = type;
    patient->scheduledTime = scheduledTime;
    patient->arrivalTime = arrivalTime;

    //initialisation
    patient->state = WAITING;
    patient->startTime = 0;
    patient->endTime = 0;
    patient->waitingTime = 0;
    patient->turnaroundTime = 0;

    //
    srand(time(NULL));
    patient->hasArrived = (arrivalTime <= scheduledTime);
    patient->urgencyLevel = (type == URGENT)?(rand()%10)+1 : 0;
}

int isPatientLate(const Patient* patient){
    return patient->arrivalTime > patient->scheduledTime;
}

void resetPatientScheduling(Patient* patient){
    patient->state = WAITING;
    patient->startTime = 0;
    patient->endTime = 0;
    patient->waitingTime = 0;
    patient->turnaroundTime = 0;
    patient->remainingTime = patient->consultationTime;
}

int shouldPromoteWalkin(const Patient* patient, int currentTime){
    if(patient->type != WALKIN || patient->state != WAITING )
        return 0;
    int waitingTime = currentTime - patient->arrivalTime;
    return waitingTime >= 180;
}

void promoteWalkin(Patient* patient, int currentTime){
    if(patient->type == WALKIN && patient->state == WAITING){
        patient->type = APPOINTMENT;
        patient->state = PROMOTED;
        patient->promotionTime = currentTime;
    }
}

int getWalkinWaitingTime(const Patient* patient, int currentTime){
    if(patient->type != WALKIN) return 0;
    return currentTime - patient->arrivalTime;
}

void displayPatientInfo(const Patient* patient){
    printf("\n=== Patient's Info ===\n");
    printf("ID : %d\n", patient->id);
    printf("Name: %s\n", patient->name);
    printf("Type: %s\n", patientTypeToString(patient->type));
    if(patient->originalType == WALKIN && patient->type == WALKIN)
        printf("!!!Promoted from Walkin!!!\n");
    printf("Priority level: %d\n",patient->type);

    printf("Scheduled time: %d\n",patientTimeToString(patient->scheduledTime));
    printf("Arrival time: %d\n",patientTimeToString(patient->arrivalTime));
    printf("Late : %s\n", isPatientLate(patient)? "Yes":"No");
    printf("Consultation time: %s\n",patientTimeToString(patient->consultationTime));
    printf("Remaining time: %s\n", patientTimeToString(patient->remainingTime));

    printf("State: %s", PStateToString(patient->state));
    
    if(patient->type == URGENT)
        printf("Urgency level: %d/10\n", patient->urgencyLevel);
    
    if(patient->promotionTime != 0)
        printf("Promoted to Appointment at : %s\n", patientTimeToString(patient->promotionTime));
    
    if(patient->state != WAITING){
        printf("Start time: %s\n", patientTimeToString(patient->startTime));
        printf("End time: %s\n", patientTimeToString(patient->endTime));
        printf("Remaining time: %d in minutes\n", patient->remainingTime);
        printf("Turnaround time: %d in minutes\n", patient->startTime);
    }

    printf("===========================");
}