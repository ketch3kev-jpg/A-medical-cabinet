#include "../include/scheduler.h"
#include <math.h>

static void init_remaining_times(Patient* patient) {
    if (patient->consultationTime <= 0) patient->consultationTime = 1;
    patient->remainingTime = patient->consultationTime;
    patient->originalType = patient->type;
    patient->state = WAITING;
    patient->startTime = -1;
    patient->endTime = -1;
    patient->waitingTime = 0;
    patient->turnaroundTime = 0;
}

// Linked List Management Functions

PatientLinkedList* createLinkedList() {
    PatientLinkedList* list = malloc(sizeof(PatientLinkedList));
    if (!list) return NULL;
    
    list->head = NULL;
    list->tail = NULL;
    list->count = 0;
    return list;
}

void freeLinkedList(PatientLinkedList* list) {
    if (!list) return;
    
    PatientNode* current = list->head;
    while (current) {
        PatientNode* next = current->next;
        free(current);
        current = next;
    }
    
    free(list);
}

void addPatientToLinkedList(PatientLinkedList* list, Patient* patient) {
    if (!list || !patient) return;
    
    PatientNode* newNode = malloc(sizeof(PatientNode));
    if (!newNode) return;
    
    newNode->patient = patient;
    newNode->next = NULL;
    
    if (!list->head) {
        list->head = newNode;
        list->tail = newNode;
    } else {
        list->tail->next = newNode;
        list->tail = newNode;
    }
    
    list->count++;
}

void insertPatientAtPosition(PatientLinkedList* list, Patient* patient, int position) {
    if (!list || !patient || position < 0 || position > list->count) return;
    
    PatientNode* newNode = malloc(sizeof(PatientNode));
    if (!newNode) return;
    
    newNode->patient = patient;
    
    if (position == 0) {
        newNode->next = list->head;
        list->head = newNode;
        if (!list->tail) list->tail = newNode;
    } else if (position == list->count) {
        newNode->next = NULL;
        if (list->tail) list->tail->next = newNode;
        list->tail = newNode;
    } else {
        PatientNode* current = list->head;
        for (int i = 0; i < position - 1; i++) {
            current = current->next;
        }
        newNode->next = current->next;
        current->next = newNode;
    }
    
    list->count++;
}

void insertPatientSortedDynamic(PatientLinkedList* list, Patient* patient, int currentTime) {
    if (!list || !patient) return;
    
    PatientNode* newNode = malloc(sizeof(PatientNode));
    if (!newNode) return;
    
    newNode->patient = patient;
    newNode->next = NULL;
    
    // If list is empty or new patient should be at head
    if (!list->head || compareByDynamicPriority(patient, list->head->patient, currentTime) <= 0) {
        newNode->next = list->head;
        list->head = newNode;
        if (!list->tail) list->tail = newNode;
        list->count++;
        return;
    }
    
    // Find the correct position
    PatientNode* current = list->head;
    while (current->next && compareByDynamicPriority(patient, current->next->patient, currentTime) > 0) {
        current = current->next;
    }
    
    newNode->next = current->next;
    current->next = newNode;
    
    // Update tail if inserted at end
    if (!newNode->next) list->tail = newNode;
    
    list->count++;
}

void removePatientFromLinkedList(PatientLinkedList* list, int patientId) {
    if (!list || !list->head) return;
    
    PatientNode* prev = NULL;
    PatientNode* current = list->head;
    
    while (current && current->patient->id != patientId) {
        prev = current;
        current = current->next;
    }
    
    if (!current) return;
    
    if (!prev) {
        list->head = current->next;
    } else {
        prev->next = current->next;
    }
    
    if (list->tail == current) {
        list->tail = prev;
    }
    
    free(current);
    list->count--;
}

Patient* findPatientInLinkedList(const PatientLinkedList* list, int patientId) {
    if (!list) return NULL;
    
    PatientNode* current = list->head;
    while (current) {
        if (current->patient->id == patientId) return current->patient;
        current = current->next;
    }
    return NULL;
}

Patient* getPatientAtPosition(const PatientLinkedList* list, int position) {
    if (!list || position < 0 || position >= list->count) return NULL;
    
    PatientNode* current = list->head;
    for (int i = 0; i < position && current; i++) {
        current = current->next;
    }
    
    return current ? current->patient : NULL;
}

void displayLinkedList(const PatientLinkedList* list) {
    if (!list || !list->head) {
        printf("Waiting list is empty.\n");
        return;
    }
    
    printf("\n=== Waiting List ===\n");
    printf("Count: %d patients\n", list->count);
    printf("Position | Patient ID | Name          | Type       | Arrival Time | State\n");
    printf("---------|------------|---------------|------------|--------------|------------\n");
    
    PatientNode* current = list->head;
    int position = 1;
    while (current) {
        Patient* p = current->patient;
        printf("%8d | %10d | %-13s | %-10s | %12s | %s\n",
               position, p->id, p->name, 
               patientTypeToString(p->type),
               patientTimeToString(p->arrivalTime),
               PStateToString(p->state));
        current = current->next;
        position++;
    }
}

// Comparison functions
int compareByArrivalTime(const Patient* a, const Patient* b) {
    return a->arrivalTime - b->arrivalTime;
}

int compareByConsultationTime(const Patient* a, const Patient* b) {
    return a->consultationTime - b->consultationTime;
}

int compareByDynamicPriority(const Patient* a, const Patient* b, int currentTime) {
    double priorityA = calculatePatientPriority(a, currentTime);
    double priorityB = calculatePatientPriority(b, currentTime);
    
    if (priorityA > priorityB) return -1;
    if (priorityA < priorityB) return 1;
    return a->arrivalTime - b->arrivalTime;
}

// Priority calculation
double calculatePatientPriority(const Patient* patient, int currentTime) {
    if (!patient) return 0.0;
    
    double basePriority = (double)patient->type;
    
    switch (patient->type) {
        case URGENT:
            return basePriority + (patient->urgencyLevel / 10.0);
            
        case APPOINTMENT:
            if (currentTime <= patient->scheduledTime) {
                double timeUntilAppointment = patient->scheduledTime - currentTime;
                return basePriority + (1.0 - (timeUntilAppointment / (patient->scheduledTime + 1.0)));
            } else {
                double lateness = currentTime - patient->scheduledTime;
                return basePriority + 1.0 + (lateness / 300.0);
            }
            
        case WALKIN: {
            int waitingTime = currentTime - patient->arrivalTime;
            if (waitingTime < 0) waitingTime = 0;
            return basePriority + (waitingTime / 90.0);
        }
        
        default:
            return basePriority;
    }
}

void displayPatientPriorities(const PatientLinkedList* list, int currentTime) {
    if (!list || !list->head) {
        printf("No patients in the list.\n");
        return;
    }
    
    printf("\n=== Patient Priorities at Time %s ===\n", patientTimeToString(currentTime));
    printf("Patient ID | Name          | Type       | Priority Score\n");
    printf("-----------|---------------|------------|---------------\n");
    
    PatientNode* current = list->head;
    while (current) {
        Patient* p = current->patient;
        double priority = calculatePatientPriority(p, currentTime);
        printf("%10d | %-13s | %-10s | %13.2f\n", 
               p->id, p->name, patientTypeToString(p->type), priority);
        current = current->next;
    }
}

void displayLinkedListStatus(const PatientLinkedList* list, int currentTime) {
    if (!list) {
        printf("Waiting list is NULL.\n");
        return;
    }
    
    if (!list->head) {
        printf("Waiting list is empty at time %s.\n", patientTimeToString(currentTime));
        return;
    }
    
    printf("\n=== Waiting List Status at %s ===\n", patientTimeToString(currentTime));
    printf("Total patients: %d\n", list->count);
    printf("Position | Patient ID | Name          | Type       | State        | Arrival | Priority\n");
    printf("---------|------------|---------------|------------|--------------|---------|----------\n");
    
    PatientNode* current = list->head;
    int position = 1;
    while (current) {
        Patient* p = current->patient;
        double priority = calculatePatientPriority(p, currentTime);
        
        printf("%8d | %10d | %-13s | %-10s | %-12s | %7s | %8.2f\n",
               position, p->id, p->name, patientTypeToString(p->type),
               PStateToString(p->state), patientTimeToString(p->arrivalTime), priority);
        
        current = current->next;
        position++;
    }
}

int getPromotionPredictions(const PatientLinkedList* list, int currentTime, int* promotedIds, int maxPromotions) {
    if (!list || !promotedIds || maxPromotions <= 0) return 0;
    
    int promotionCount = 0;
    PatientNode* current = list->head;
    
    while (current && promotionCount < maxPromotions) {
        Patient* p = current->patient;
        
        if (p->type == WALKIN && p->state == WAITING) {
            int waitingTime = currentTime - p->arrivalTime;
            if (waitingTime >= 180) {
                promotedIds[promotionCount++] = p->id;
            }
        }
        
        current = current->next;
    }
    
    return promotionCount;
}

void calculateLinkedListStatistics(const PatientLinkedList* list, QueueData* stats) {
    if (!list || !stats) return;
    
    memset(stats, 0, sizeof(QueueData));
    stats->numPatient = list->count;
    
    PatientNode* current = list->head;
    while (current) {
        Patient* p = current->patient;
        switch (p->type) {
            case WALKIN: stats->walkinCount++; break;
            case APPOINTMENT: stats->appointmentCount++; break;
            case URGENT: stats->urgentCount++; break;
        }   
        if (p->type == APPOINTMENT && isPatientLate(p)) stats->lateAppointments++;
        if (p->type == WALKIN && p->state == PROMOTED) stats->promotedWalkins++;
        if (p->waitingTime > stats->maxWaitingTime) stats->maxWaitingTime = p->waitingTime;
        if (p->type == WALKIN && p->waitingTime > stats->maxWalkinWaiting) stats->maxWalkinWaiting = p->waitingTime;

        current = current->next;
    }
}

// Section division and hybrid scheduling
SectionedWaitingList* divideByDynamicPriority(PatientLinkedList* list, int currentTime) {
    if (!list || list->count == 0) return NULL;
    
    SectionedWaitingList* sectionedList = malloc(sizeof(SectionedWaitingList));
    if (!sectionedList) return NULL;
    
    // Count patients by type
    int urgentCount = 0, appointmentCount = 0, walkinCount = 0;
    PatientNode* current = list->head;
    
    while (current) {
        switch (current->patient->type) {
            case URGENT: urgentCount++; break;
            case APPOINTMENT: appointmentCount++; break;
            case WALKIN: walkinCount++; break;
        }
        current = current->next;
    }
    
    // Allocate sections
    sectionedList->sectionCount = 0;
    if (urgentCount > 0) sectionedList->sectionCount++;
    if (appointmentCount > 0) sectionedList->sectionCount++;
    if (walkinCount > 0) sectionedList->sectionCount++;
    
    sectionedList->sections = malloc(sizeof(PrioritySection) * sectionedList->sectionCount);
    sectionedList->totalPatients = list->count;
    
    // Initialize sections
    int sectionIndex = 0;
    
    // Urgent section
    if (urgentCount > 0) {
        sectionedList->sections[sectionIndex].type = URGENT;
        sectionedList->sections[sectionIndex].count = urgentCount;
        sectionedList->sections[sectionIndex].patients = malloc(sizeof(Patient*) * urgentCount);
        sectionIndex++;
    }
    
    // Appointment section
    if (appointmentCount > 0) {
        sectionedList->sections[sectionIndex].type = APPOINTMENT;
        sectionedList->sections[sectionIndex].count = appointmentCount;
        sectionedList->sections[sectionIndex].patients = malloc(sizeof(Patient*) * appointmentCount);
        sectionIndex++;
    }
    
    // Walk-in section
    if (walkinCount > 0) {
        sectionedList->sections[sectionIndex].type = WALKIN;
        sectionedList->sections[sectionIndex].count = walkinCount;
        sectionedList->sections[sectionIndex].patients = malloc(sizeof(Patient*) * walkinCount);
    }
    
    // Populate sections with patients
    int urgentIdx = 0, appointmentIdx = 0, walkinIdx = 0;
    current = list->head;
    
    while (current) {
        Patient* p = current->patient;
        
        switch (p->type) {
            case URGENT:
                sectionedList->sections[0].patients[urgentIdx++] = p;
                break;
            case APPOINTMENT:
                sectionedList->sections[urgentCount > 0 ? 1 : 0].patients[appointmentIdx++] = p;
                break;
            case WALKIN:
                {
                    int walkinSection = (urgentCount > 0 ? 1 : 0) + (appointmentCount > 0 ? 1 : 0);
                    sectionedList->sections[walkinSection].patients[walkinIdx++] = p;
                }
                break;
        }
        current = current->next;
    }
    
    // Sort each section by dynamic priority using compareByDynamicPriority
    for (int i = 0; i < sectionedList->sectionCount; i++) {
        PrioritySection* section = &sectionedList->sections[i];
        
        // Bubble sort using compareByDynamicPriority
        for (int j = 0; j < section->count - 1; j++) {
            for (int k = 0; k < section->count - j - 1; k++) {
                // Use compareByDynamicPriority to determine order
                // descending order (highest priority first)
                if (compareByDynamicPriority(section->patients[k], section->patients[k + 1], currentTime) > 0) {
                    // Swap if current patient should come after next patient
                    Patient* temp = section->patients[k];
                    section->patients[k] = section->patients[k + 1];
                    section->patients[k + 1] = temp;
                }
            }
        }
    }
    
    return sectionedList;
}

void freeSectionedList(SectionedWaitingList* sectionedList) {
    if (!sectionedList) return;
    
    for (int i = 0; i < sectionedList->sectionCount; i++) {
        free(sectionedList->sections[i].patients);
    }
    free(sectionedList->sections);
    free(sectionedList);
}

void displaySectionedList(const SectionedWaitingList* sectionedList) {
    if (!sectionedList) {
        printf("Sectioned list is NULL.\n");
        return;
    }
    
    printf("\n=== SECTIONED WAITING LIST ===\n");
    printf("Total sections: %d\n", sectionedList->sectionCount);
    printf("Total patients: %d\n", sectionedList->totalPatients);
    
    for (int i = 0; i < sectionedList->sectionCount; i++) {
        const PrioritySection* section = &sectionedList->sections[i];
        
        printf("\n--- %s Section (%d patients) ---\n", 
               patientTypeToString(section->type), section->count);
        printf("ID  | Name          | Priority | Arrival   | Consultation\n");
        printf("----|---------------|----------|-----------|-------------\n");
        
        for (int j = 0; j < section->count; j++) {
            Patient* p = section->patients[j];
            printf("%3d | %-13s | %8.2f | %9s | %11d\n",
                   p->id, p->name, calculatePatientPriority(p, 0),
                   patientTimeToString(p->arrivalTime), p->consultationTime);
        }
    }
}

// functions to simplify my scheduler
static int hasUrgentArrived(SectionedWaitingList* sectionedList, int currentTime, int consultingPatientId) {
    for (int i = 0; i < sectionedList->sectionCount; i++) {
        PrioritySection* section = &sectionedList->sections[i];
        
        if (section->type == URGENT) {
            for (int j = 0; j < section->count; j++) {
                Patient* p = section->patients[j];
                if (p->arrivalTime <= currentTime && p->state == WAITING && p->id != consultingPatientId) {
                    return 1;
                }
            }
        }
    }
    return 0;
}

static int findSamePriorityGroup(PrioritySection* section, int currentIndex, int currentTime, 
                                Patient** samePriorityPatients, int maxPatients) {
    if (!section || currentIndex >= section->count) return 0;
    
    Patient* reference = section->patients[currentIndex];
    double refPriority = calculatePatientPriority(reference, currentTime);
    int refArrival = reference->arrivalTime;
    
    int count = 0;
    samePriorityPatients[count++] = reference;
    
    for (int i = currentIndex + 1; i < section->count && count < maxPatients; i++) {
        Patient* p = section->patients[i];
        double priority = calculatePatientPriority(p, currentTime);
        int arrival = p->arrivalTime;
        
        if (fabs(priority - refPriority) < 1e-6 && arrival == refArrival) {
            samePriorityPatients[count++] = p;
        } else {
            break;
        }
    }
    
    return count;
}

static Patient* selectRandomPatient(Patient** patients, int count) {
    static int initialized = 0;
    if (!initialized) {
        srand(time(NULL));
        initialized = 1;
    }
    return patients[rand() % count];
}

// Global RR state
static RRGroup currentRRGroup = {0};
static int rrGroupActive = 0;

void runHybridScheduler(SectionedWaitingList* sectionedList, Doctor* doctor) {
    if (!sectionedList || sectionedList->totalPatients == 0) return;
    
    printf("\n=== STARTING HYBRID SCHEDULER ===\n");
    
    int currentTime = 0;
    int totalCompleted = 0;
    Patient* currentPatient = NULL;
    int remainingTime = 0;
    
    for (int i = 0; i < sectionedList->sectionCount; i++) {
        PrioritySection* section = &sectionedList->sections[i];
        for (int j = 0; j < section->count; j++) {
            init_remaining_times(section->patients[j]);
        }
    }
    
    int* sectionPointers = calloc(sectionedList->sectionCount, sizeof(int));
    Patient* samePriorityPatients[100];
    
    while (totalCompleted < sectionedList->totalPatients) {
        if (currentPatient && hasUrgentArrived(sectionedList, currentTime, currentPatient->id)) {
            if (currentPatient->type != URGENT) {
                printf("  -> PREEMPTION: Urgent patient arrived, preempting %s (%s)\n",
                       currentPatient->name, patientTypeToString(currentPatient->type));
                
                currentPatient->remainingTime = remainingTime;
                currentPatient->state = WAITING;
                currentPatient = NULL;
                remainingTime = 0;
                rrGroupActive = 0;
            }
        }
        
        if (!currentPatient) {
            if (!rrGroupActive) {
                currentRRGroup.patients = NULL;
                currentRRGroup.count = 0;
                currentRRGroup.currentIndex = 0;
            }
            
            for (int i = 0; i < sectionedList->sectionCount; i++) {
                PrioritySection* section = &sectionedList->sections[i];
                
                if (rrGroupActive && section->type == URGENT && currentRRGroup.count > 0) {
                    currentPatient = currentRRGroup.patients[currentRRGroup.currentIndex];
                    currentRRGroup.currentIndex = (currentRRGroup.currentIndex + 1) % currentRRGroup.count;
                    
                    if (currentPatient->state == WAITING && 
                        currentPatient->arrivalTime <= currentTime && 
                        currentPatient->remainingTime > 0) {
                        
                        remainingTime = (currentPatient->remainingTime < TIME_QUANTUM) ? currentPatient->remainingTime : TIME_QUANTUM;
                        
                        if (currentPatient->startTime == -1) {
                            currentPatient->startTime = currentTime;
                        }
                        currentPatient->state = IN_CONSULTATION;
                        
                        printf("  -> RR Consulting: %s (%s) for %d minutes\n",
                               currentPatient->name, patientTypeToString(currentPatient->type), remainingTime);
                        break;
                    } else {
                        currentPatient = NULL;
                        continue;
                    }
                }
                
                for (int j = sectionPointers[i]; j < section->count; j++) {
                    Patient* p = section->patients[j];
                    
                    if (p->state == WAITING && p->arrivalTime <= currentTime && p->remainingTime > 0) {
                        
                        if (section->type == URGENT) {
                            int samePriorityCount = findSamePriorityGroup(section, j, currentTime, 
                                                                        samePriorityPatients, 100);
                            
                            if (samePriorityCount > 1) {
                                printf("  -> Found %d urgent patients with same priority\n", samePriorityCount);
                                
                                currentRRGroup.patients = malloc(sizeof(Patient*) * samePriorityCount);
                                for (int k = 0; k < samePriorityCount; k++) {
                                    currentRRGroup.patients[k] = samePriorityPatients[k];
                                }
                                currentRRGroup.count = samePriorityCount;
                                currentRRGroup.currentIndex = 0;
                                currentRRGroup.lastServedTime = currentTime;
                                rrGroupActive = 1;
                                
                                currentPatient = currentRRGroup.patients[0];
                                currentRRGroup.currentIndex = 1;
                                sectionPointers[i] = j + samePriorityCount;
                            } else {
                                currentPatient = p;
                                sectionPointers[i] = j + 1;
                            }
                        } else if (section->type == WALKIN) {
                            int samePriorityCount = findSamePriorityGroup(section, j, currentTime, 
                                                                        samePriorityPatients, 100);
                            
                            if (samePriorityCount > 1) {
                                printf("  -> Found %d walk-in patients with same priority\n", samePriorityCount);
                                currentPatient = selectRandomPatient(samePriorityPatients, samePriorityCount);
                                
                                int selectedIndex = j;
                                for (int k = 0; k < samePriorityCount; k++) {
                                    if (samePriorityPatients[k] == currentPatient) {
                                        selectedIndex = j + k;
                                        break;
                                    }
                                }
                                sectionPointers[i] = selectedIndex + 1;
                            } else {
                                currentPatient = p;
                                sectionPointers[i] = j + 1;
                            }
                        } else {
                            currentPatient = p;
                            sectionPointers[i] = j + 1;
                        }
                        
                        remainingTime = currentPatient->remainingTime;
                        
                        if (currentPatient->type == URGENT && !rrGroupActive) {
                            remainingTime = (currentPatient->remainingTime < TIME_QUANTUM) ? currentPatient->remainingTime : TIME_QUANTUM;
                        }
                        
                        if (currentPatient->startTime == -1) {
                            currentPatient->startTime = currentTime;
                        }
                        currentPatient->state = IN_CONSULTATION;
                        
                        if (!rrGroupActive) {
                            printf("  -> Consulting: %s (%s) for %d minutes\n",
                                   currentPatient->name, patientTypeToString(currentPatient->type), remainingTime);
                        }
                        break;
                    }
                }
                if (currentPatient) break;
            }
            
            if (!currentPatient) {
                currentTime++;
                if (rrGroupActive && currentTime - currentRRGroup.lastServedTime > 30) {
                    rrGroupActive = 0;
                    if (currentRRGroup.patients) {
                        free(currentRRGroup.patients);
                        currentRRGroup.patients = NULL;
                    }
                }
                continue;
            }
        }
        
        currentPatient->remainingTime--;
        remainingTime--;
        currentTime++;
        
        if (rrGroupActive) {
            currentRRGroup.lastServedTime = currentTime;
        }
        
        if (currentPatient->remainingTime == 0) {
            currentPatient->endTime = currentTime;
            currentPatient->turnaroundTime = currentPatient->endTime - currentPatient->arrivalTime;
            currentPatient->waitingTime = currentPatient->startTime - currentPatient->arrivalTime;
            if (currentPatient->waitingTime < 0) currentPatient->waitingTime = 0;
            currentPatient->state = COMPLETED;
            
            printf("  -> COMPLETED: %s (%s) at %s\n",
                   currentPatient->name, patientTypeToString(currentPatient->type),
                   patientTimeToString(currentTime));
            
            totalCompleted++;
            currentPatient = NULL;
            remainingTime = 0;
            
            if (rrGroupActive && currentRRGroup.count > 0) {
                int allCompleted = 1;
                for (int i = 0; i < currentRRGroup.count; i++) {
                    if (currentRRGroup.patients[i]->state != COMPLETED) {
                        allCompleted = 0;
                        break;
                    }
                }
                if (allCompleted) {
                    free(currentRRGroup.patients);
                    currentRRGroup.patients = NULL;
                    currentRRGroup.count = 0;
                    rrGroupActive = 0;
                }
            }
            
            if (doctor) {
                currentTime += doctor->gapBetweenPatients;
            }
        } else if (remainingTime == 0 && currentPatient->type == URGENT) {
            currentPatient->state = WAITING;
            printf("  -> Time quantum expired for %s (%s)\n",
                   currentPatient->name, patientTypeToString(currentPatient->type));
            currentPatient = NULL;
        }
        
        for (int i = 0; i < sectionedList->sectionCount; i++) {
            PrioritySection* section = &sectionedList->sections[i];
            
            if (section->type == WALKIN) {
                for (int j = 0; j < section->count; j++) {
                    Patient* p = section->patients[j];
                    if (p->type == WALKIN && p->state == WAITING && p->remainingTime > 0) {
                        if (shouldPromoteWalkin(p, currentTime)) {
                            promoteWalkin(p, currentTime);
                            printf("  -> PROMOTION: Walk-in %s promoted to appointment\n", p->name);
                        }
                    }
                }
            }
        }
    }
    
    if (currentRRGroup.patients) {
        free(currentRRGroup.patients);
    }
    
    free(sectionPointers);
    
    if (doctor) {
        doctor->currentTime = doctor->startTime + currentTime;
        doctor->patientsSeen += sectionedList->totalPatients;
        doctor->totalConsultationTime += currentTime;
    }
    
    printf("Hybrid scheduling completed. Total time: %d minutes\n", currentTime);
}

// Scheduling Algorithms

void runSJF_section(PatientLinkedList* list, Doctor* doctor, int start_index, int end_index) {
    if (!list || list->count <= 0 || start_index < 0 || end_index >= list->count || start_index > end_index) {
        printf("Error: Invalid section indices\n");
        return;
    }
    
    int section_count = end_index - start_index + 1;
    Patient** section_patients = malloc(sizeof(Patient*) * section_count);
    int* indices = malloc(sizeof(int) * section_count);
    
    PatientNode* current = list->head;
    for (int i = 0; i <= end_index && current; i++) {
        if (i >= start_index) {
            int idx = i - start_index;
            section_patients[idx] = current->patient;
            indices[idx] = idx;
            init_remaining_times(current->patient);
        }
        current = current->next;
    }
    
    for (int i = 0; i < section_count - 1; i++) {
        int minj = i;
        for (int j = i + 1; j < section_count; j++) {
            if (section_patients[indices[j]]->consultationTime < section_patients[indices[minj]]->consultationTime)
                minj = j;
        }
        if (minj != i) {
            int tmp = indices[i];
            indices[i] = indices[minj];
            indices[minj] = tmp;
        }
    }
    
    int currentTime = 0;
    for (int i = 0; i < section_count; i++) {
        Patient* p = section_patients[indices[i]];
        if (currentTime < p->arrivalTime) currentTime = p->arrivalTime;
        p->startTime = currentTime;
        p->waitingTime = p->startTime - p->arrivalTime;
        p->endTime = p->startTime + p->consultationTime;
        p->turnaroundTime = p->endTime - p->arrivalTime;
        p->remainingTime = 0;
        p->state = COMPLETED;
        currentTime = p->endTime;
    }
    
    free(section_patients);
    free(indices);
    
    if (doctor) {
        doctor->currentTime = doctor->startTime + currentTime;
        doctor->patientsSeen += section_count;
    }
}

void runFCFS_section(PatientLinkedList* list, Doctor* doctor, int start_index, int end_index) {
    if (!list || list->count <= 0 || start_index < 0 || end_index >= list->count || start_index > end_index) {
        printf("Error: Invalid section indices\n");
        return;
    }
    
    int section_count = end_index - start_index + 1;
    Patient** section_patients = malloc(sizeof(Patient*) * section_count);
    int* indices = malloc(sizeof(int) * section_count);
    
    PatientNode* current = list->head;
    for (int i = 0; i <= end_index && current; i++) {
        if (i >= start_index) {
            int idx = i - start_index;
            section_patients[idx] = current->patient;
            indices[idx] = idx;
            init_remaining_times(current->patient);
        }
        current = current->next;
    }
    
    for (int i = 0; i < section_count - 1; i++) {
        int minj = i;
        for (int j = i + 1; j < section_count; j++) {
            if (section_patients[indices[j]]->arrivalTime < section_patients[indices[minj]]->arrivalTime)
                minj = j;
        }
        if (minj != i) {
            int tmp = indices[i];
            indices[i] = indices[minj];
            indices[minj] = tmp;
        }
    }
    
    int currentTime = 0;
    for (int k = 0; k < section_count; k++) {
        Patient* p = section_patients[indices[k]];
        if (currentTime < p->arrivalTime) currentTime = p->arrivalTime;
        p->startTime = currentTime;
        p->waitingTime = p->startTime - p->arrivalTime;
        if (p->waitingTime < 0) p->waitingTime = 0;
        p->endTime = p->startTime + p->consultationTime;
        p->turnaroundTime = p->endTime - p->arrivalTime;
        p->remainingTime = 0;
        p->state = COMPLETED;
        currentTime = p->endTime;
    }
    
    free(section_patients);
    free(indices);
    
    if (doctor) {
        doctor->currentTime = doctor->startTime + currentTime;
        doctor->patientsSeen += section_count;
    }
}

void runRoundRobin_section(PatientLinkedList* list, Doctor* doctor, int start_index, int end_index) {
    if (!list || list->count <= 0 || start_index < 0 || end_index >= list->count || start_index > end_index) {
        printf("Error: Invalid section indices\n");
        return;
    }
    
    int section_count = end_index - start_index + 1;
    
    PatientNode* current = list->head;
    for (int i = 0; i <= end_index && current; i++) {
        if (i >= start_index) init_remaining_times(current->patient);
        current = current->next;
    }
    
    PatientLinkedList* readyQueue = createLinkedList();
    int completed = 0;
    int currentTime = 0;
    int* inQueue = calloc(section_count, sizeof(int));
    
    while (completed < section_count) {
        current = list->head;
        int global_index = 0;
        int section_index = 0;
        while (current && global_index <= end_index) {
            if (global_index >= start_index) {
                if (current->patient->arrivalTime <= currentTime && 
                    !inQueue[section_index] && 
                    current->patient->remainingTime > 0) {
                    addPatientToLinkedList(readyQueue, current->patient);
                    inQueue[section_index] = 1;
                }
                section_index++;
            }
            current = current->next;
            global_index++;
        }
        
        if (readyQueue->count == 0) {
            currentTime++;
            continue;
        }
        
        Patient* currentPatient = readyQueue->head->patient;
        removePatientFromLinkedList(readyQueue, currentPatient->id);
        
        current = list->head;
        global_index = 0;
        section_index = 0;
        while (current && global_index <= end_index) {
            if (global_index >= start_index) {
                if (current->patient == currentPatient) {
                    inQueue[section_index] = 0;
                    break;
                }
                section_index++;
            }
            current = current->next;
            global_index++;
        }
        
        if (currentPatient->startTime == -1) currentPatient->startTime = currentTime;
        
        int runTime = (currentPatient->remainingTime < TIME_QUANTUM) ? currentPatient->remainingTime : TIME_QUANTUM;
        currentPatient->remainingTime -= runTime;
        currentTime += runTime;
        
        if (currentPatient->remainingTime == 0) {
            currentPatient->endTime = currentTime;
            currentPatient->turnaroundTime = currentPatient->endTime - currentPatient->arrivalTime;
            currentPatient->waitingTime = currentPatient->turnaroundTime - currentPatient->consultationTime;
            if (currentPatient->waitingTime < 0) currentPatient->waitingTime = 0;
            currentPatient->state = COMPLETED;
            completed++;
        } else {
            addPatientToLinkedList(readyQueue, currentPatient);
            if (current) inQueue[section_index] = 1;
        }
    }
    
    freeLinkedList(readyQueue);
    free(inQueue);
    
    if (doctor) {
        doctor->currentTime = doctor->startTime + currentTime;
        doctor->patientsSeen += section_count;
    }
}

// Priority Scheduling for a section of the linked list
void runPriorityScheduling_section(PatientLinkedList* list, Doctor* doctor, int start_index, int end_index) {
    if (!list || list->count <= 0 || start_index < 0 || end_index >= list->count || start_index > end_index) {
        printf("Error: Invalid section indices\n");
        return;
    }
    
    int section_count = end_index - start_index + 1;
    
    // Initialize patients in the section
    PatientNode* current = list->head;
    for (int i = 0; i <= end_index && current; i++) {
        if (i >= start_index) init_remaining_times(current->patient);
        current = current->next;
    }
    
    // Create a sorted list by dynamic priority for the section
    PatientLinkedList* sortedList = createLinkedList();
    current = list->head;
    
    int currentTime = 0; // Start time for scheduling
    
    for (int i = 0; i <= end_index && current; i++) {
        if (i >= start_index) {
            // Use wrapper function for insertion that works with compareByDynamicPriority
            Patient* patient = current->patient;
            PatientNode* newNode = malloc(sizeof(PatientNode));
            if (!newNode) continue;
            
            newNode->patient = patient;
            newNode->next = NULL;
            
            // Insert sorted by dynamic priority at currentTime
            if (!sortedList->head) {
                sortedList->head = newNode;
                sortedList->tail = newNode;
            } else {
                // Manual insertion sort using compareByDynamicPriority
                PatientNode* prev = NULL;
                PatientNode* curr = sortedList->head;
                
                while (curr && compareByDynamicPriority(patient, curr->patient, currentTime) > 0) {
                    prev = curr;
                    curr = curr->next;
                }
                
                if (!prev) {
                    newNode->next = sortedList->head;
                    sortedList->head = newNode;
                } else {
                    prev->next = newNode;
                    newNode->next = curr;
                }
                
                if (!curr) {
                    sortedList->tail = newNode;
                }
            }
            sortedList->count++;
        }
        current = current->next;
    }
    
    // Execute patients in priority order
    currentTime = 0;
    PatientNode* scheduleCurrent = sortedList->head;
    while (scheduleCurrent) {
        Patient* p = scheduleCurrent->patient;
        if (currentTime < p->arrivalTime) currentTime = p->arrivalTime;
        p->startTime = currentTime;
        p->waitingTime = p->startTime - p->arrivalTime;
        p->endTime = p->startTime + p->consultationTime;
        p->turnaroundTime = p->endTime - p->arrivalTime;
        p->remainingTime = 0;
        p->state = COMPLETED;
        currentTime = p->endTime;
        scheduleCurrent = scheduleCurrent->next;
    }
    
    freeLinkedList(sortedList);
    
    if (doctor) {
        doctor->currentTime = doctor->startTime + currentTime;
        doctor->patientsSeen += section_count;
    }
}

// Wrapper functions for entire list
void runSJF(PatientLinkedList* list, Doctor* doctor) {
    runSJF_section(list, doctor, 0, list->count - 1);
}

void runFCFS(PatientLinkedList* list, Doctor* doctor) {
    runFCFS_section(list, doctor, 0, list->count - 1);
}

void runRoundRobin(PatientLinkedList* list, Doctor* doctor) {
    runRoundRobin_section(list, doctor, 0, list->count - 1);
}

void runPriorityScheduling(PatientLinkedList* list, Doctor* doctor) {
    runPriorityScheduling_section(list, doctor, 0, list->count - 1);
}