#include "../include/scheduler.h"
#include "../include/patient.h"
#include "../include/doctor.h"
#include <time.h>

// Global variables
PatientLinkedList* global_patient_list = NULL;
Doctor global_doctor;

// Function prototypes
void initialize_system();
void cleanup_system();
void create_sample_patients();
void display_patient_list();
void run_simulation();
void display_statistics();
void cli_add_patient();
void cli_edit_patient();
void cli_delete_patient();
void cli_run_simulation_menu();
void cli_display_patients();
void cli_main_menu();

int main(int argc, char *argv[]) {
    printf("=== MEDICAL CABINET DOCTOR SCHEDULING SYSTEM ===\n");
    printf("=== (Re)Planification Module - CLI Version ===\n\n");

    // Initialize system
    initialize_system();

    // Start CLI interface
    cli_main_menu();

    // Cleanup
    cleanup_system();
    return 0;
}

void initialize_system() {
    // Initialize global patient list
    global_patient_list = createLinkedList();
    if (!global_patient_list) {
        printf("Error: Could not create patient list!\n");
        exit(1);
    }

    // Initialize doctor
    initialiseDoctor(&global_doctor, "Dr. Smith");
    
    printf("System initialized successfully.\n");
}

void cleanup_system() {
    if (global_patient_list) {
        // Free all patients and the list
        PatientNode* current = global_patient_list->head;
        while (current) {
            PatientNode* next = current->next;
            free(current->patient);
            free(current);
            current = next;
        }
        free(global_patient_list);
    }
    printf("System cleanup completed.\n");
}

void create_sample_patients() {
    printf("\n=== CREATING SAMPLE PATIENTS ===\n");
    
    // Clear existing list
    PatientNode* current = global_patient_list->head;
    while (current) {
        PatientNode* next = current->next;
        free(current->patient);
        free(current);
        current = next;
    }
    global_patient_list->head = NULL;
    global_patient_list->tail = NULL;
    global_patient_list->count = 0;

    // Sample patients with realistic times (in minutes from 8:00 AM)
    Patient* patients[10];
    
    // Urgent cases
    patients[0] = malloc(sizeof(Patient));
    initialisePatient(patients[0], 1, "John Emergency", URGENT, -1, 30, 15);
    
    patients[1] = malloc(sizeof(Patient));
    initialisePatient(patients[1], 2, "Maria Critical", URGENT, -1, 120, 20);
    
    // Appointments
    patients[2] = malloc(sizeof(Patient));
    initialisePatient(patients[2], 3, "Robert Wilson", APPOINTMENT, 60, 55, 25);
    
    patients[3] = malloc(sizeof(Patient));
    initialisePatient(patients[3], 4, "Sarah Johnson", APPOINTMENT, 90, 85, 15);
    
    patients[4] = malloc(sizeof(Patient));
    initialisePatient(patients[4], 5, "Michael Brown", APPOINTMENT, 150, 160, 30);
    
    // Walk-ins
    patients[5] = malloc(sizeof(Patient));
    initialisePatient(patients[5], 6, "Emily Davis", WALKIN, -1, 45, 10);
    
    patients[6] = malloc(sizeof(Patient));
    initialisePatient(patients[6], 7, "David Miller", WALKIN, -1, 100, 12);
    
    patients[7] = malloc(sizeof(Patient));
    initialisePatient(patients[7], 8, "Lisa Garcia", WALKIN, -1, 180, 8);
    
    // Additional patients
    patients[8] = malloc(sizeof(Patient));
    initialisePatient(patients[8], 9, "Thomas Lee", APPOINTMENT, 200, 195, 18);
    
    patients[9] = malloc(sizeof(Patient));
    initialisePatient(patients[9], 10, "Jennifer White", URGENT, -1, 240, 22);

    // Add to linked list
    for (int i = 0; i < 10; i++) {
        addPatientToLinkedList(global_patient_list, patients[i]);
    }

    printf("Created 10 sample patients:\n");
    printf("- 3 Urgent cases\n");
    printf("- 4 Appointments (1 late)\n");
    printf("- 3 Walk-ins\n");
}

void cli_main_menu() {
    int choice;
    do {
        printf("\n=== MAIN MENU ===\n");
        printf("1. Add New Patient\n");
        printf("2. Display All Patients\n");
        printf("3. Edit Patient\n");
        printf("4. Delete Patient\n");
        printf("5. Create Sample Patients\n");
        printf("6. Run Scheduling Simulation\n");
        printf("7. Display Statistics\n");
        printf("8. Display Doctor Status\n");
        printf("9. Exit\n");
        printf("Enter your choice: ");
        
        if (scanf("%d", &choice) != 1) {
            printf("Invalid input! Please enter a number.\n");
            while (getchar() != '\n'); // Clear input buffer
            continue;
        }
        
        switch(choice) {
            case 1:
                cli_add_patient();
                break;
            case 2:
                cli_display_patients();
                break;
            case 3:
                cli_edit_patient();
                break;
            case 4:
                cli_delete_patient();
                break;
            case 5:
                create_sample_patients();
                break;
            case 6:
                cli_run_simulation_menu();
                break;
            case 7:
                display_statistics();
                break;
            case 8:
                displayDoctorStatus(&global_doctor);
                break;
            case 9:
                printf("Exiting system...\n");
                break;
            default:
                printf("Invalid choice! Please try again.\n");
        }
    } while(choice != 9);
}

void cli_add_patient() {
    printf("\n=== ADD NEW PATIENT ===\n");
    
    Patient* new_patient = malloc(sizeof(Patient));
    if (!new_patient) {
        printf("Error: Could not allocate memory for new patient!\n");
        return;
    }
    
    int id, type_choice, scheduled_hour, scheduled_minute, arrival_hour, arrival_minute, consultation_time;
    char name[40];
    
    printf("Enter Patient ID: ");
    if (scanf("%d", &id) != 1) {
        printf("Invalid ID!\n");
        free(new_patient);
        return;
    }
    
    // Check if ID already exists
    if (findPatientInLinkedList(global_patient_list, id)) {
        printf("Error: Patient ID %d already exists!\n", id);
        free(new_patient);
        return;
    }
    
    printf("Enter Patient Name: ");
    scanf(" %[^\n]", name);
    
    printf("Select Patient Type:\n");
    printf("1. Urgent\n");
    printf("2. Appointment\n");
    printf("3. Walk-in\n");
    printf("Enter choice: ");
    scanf("%d", &type_choice);
    
    AppointmentType type;
    switch(type_choice) {
        case 1: type = URGENT; break;
        case 2: type = APPOINTMENT; break;
        case 3: type = WALKIN; break;
        default: 
            printf("Invalid type! Defaulting to Walk-in.\n");
            type = WALKIN;
    }
    
    int scheduled_time = -1;
    if (type == APPOINTMENT) {
        printf("Enter scheduled time (HH MM): ");
        scanf("%d %d", &scheduled_hour, &scheduled_minute);
        scheduled_time = (scheduled_hour - 8) * 60 + scheduled_minute;
    }
    
    printf("Enter arrival time (HH MM): ");
    scanf("%d %d", &arrival_hour, &arrival_minute);
    int arrival_time = (arrival_hour - 8) * 60 + arrival_minute;
    
    printf("Enter consultation time (minutes): ");
    scanf("%d", &consultation_time);
    
    if (consultation_time <= 0) {
        printf("Error: Consultation time must be positive!\n");
        free(new_patient);
        return;
    }
    
    initialisePatient(new_patient, id, name, type, scheduled_time, arrival_time, consultation_time);
    addPatientToLinkedList(global_patient_list, new_patient);
    
    printf("Patient added successfully!\n");
}

void cli_display_patients() {
    if (global_patient_list->count == 0) {
        printf("No patients in the system!\n");
        return;
    }
    
    printf("\n=== PATIENT LIST ===\n");
    printf("ID  | Name           | Type       | Arrival | Scheduled | Consultation | State\n");
    printf("----|----------------|------------|---------|-----------|--------------|------------\n");
    
    PatientNode* current = global_patient_list->head;
    while (current) {
        Patient* p = current->patient;
        printf("%-3d | %-14s | %-10s | %7s | %9s | %12d | %s\n",
               p->id, p->name, patientTypeToString(p->type),
               patientTimeToString(p->arrivalTime),
               p->scheduledTime >= 0 ? patientTimeToString(p->scheduledTime) : "N/A",
               p->consultationTime,
               PStateToString(p->state));
        current = current->next;
    }
    printf("Total patients: %d\n", global_patient_list->count);
}

void cli_edit_patient() {
    if (global_patient_list->count == 0) {
        printf("No patients to edit!\n");
        return;
    }
    
    printf("\n=== EDIT PATIENT ===\n");
    cli_display_patients();
    
    int patient_id;
    printf("Enter Patient ID to edit: ");
    scanf("%d", &patient_id);
    
    Patient* patient = findPatientInLinkedList(global_patient_list, patient_id);
    if (!patient) {
        printf("Error: Patient with ID %d not found!\n", patient_id);
        return;
    }
    
    printf("Editing patient: %s (ID: %d)\n", patient->name, patient->id);
    
    int choice;
    printf("What would you like to edit?\n");
    printf("1. Name\n");
    printf("2. Type\n");
    printf("3. Arrival Time\n");
    printf("4. Scheduled Time\n");
    printf("5. Consultation Time\n");
    printf("Enter choice: ");
    scanf("%d", &choice);
    
    switch(choice) {
        case 1: {
            char new_name[40];
            printf("Enter new name: ");
            scanf(" %[^\n]", new_name);
            strncpy(patient->name, new_name, sizeof(patient->name) - 1);
            patient->name[sizeof(patient->name) - 1] = '\0';
            printf("Name updated successfully.\n");
            break;
        }
        case 2: {
            int type_choice;
            printf("Select new type:\n");
            printf("1. Urgent\n");
            printf("2. Appointment\n");
            printf("3. Walk-in\n");
            printf("Enter choice: ");
            scanf("%d", &type_choice);
            
            switch(type_choice) {
                case 1: patient->type = URGENT; break;
                case 2: patient->type = APPOINTMENT; break;
                case 3: patient->type = WALKIN; break;
                default: printf("Invalid type! No change made.\n");
            }
            printf("Type updated successfully.\n");
            break;
        }
        case 3: {
            int hour, minute;
            printf("Enter new arrival time (HH MM): ");
            scanf("%d %d", &hour, &minute);
            patient->arrivalTime = (hour - 8) * 60 + minute;
            printf("Arrival time updated successfully.\n");
            break;
        }
        case 4: {
            if (patient->type == APPOINTMENT) {
                int hour, minute;
                printf("Enter new scheduled time (HH MM): ");
                scanf("%d %d", &hour, &minute);
                patient->scheduledTime = (hour - 8) * 60 + minute;
                printf("Scheduled time updated successfully.\n");
            } else {
                printf("Error: Only appointment patients have scheduled times!\n");
            }
            break;
        }
        case 5: {
            int new_time;
            printf("Enter new consultation time (minutes): ");
            scanf("%d", &new_time);
            if (new_time > 0) {
                patient->consultationTime = new_time;
                printf("Consultation time updated successfully.\n");
            } else {
                printf("Error: Consultation time must be positive!\n");
            }
            break;
        }
        default:
            printf("Invalid choice! No changes made.\n");
    }
}

void cli_delete_patient() {
    if (global_patient_list->count == 0) {
        printf("No patients to delete!\n");
        return;
    }
    
    printf("\n=== DELETE PATIENT ===\n");
    cli_display_patients();
    
    int patient_id;
    printf("Enter Patient ID to delete: ");
    scanf("%d", &patient_id);
    
    Patient* patient = findPatientInLinkedList(global_patient_list, patient_id);
    if (!patient) {
        printf("Error: Patient with ID %d not found!\n", patient_id);
        return;
    }
    
    printf("Are you sure you want to delete patient '%s' (ID: %d)? (y/n): ", 
           patient->name, patient->id);
    char confirm;
    scanf(" %c", &confirm);
    
    if (confirm == 'y' || confirm == 'Y') {
        removePatientFromLinkedList(global_patient_list, patient_id);
        free(patient);
        printf("Patient deleted successfully.\n");
    } else {
        printf("Deletion cancelled.\n");
    }
}

void cli_run_simulation_menu() {
    if (global_patient_list->count == 0) {
        printf("No patients in the list! Please add patients first.\n");
        return;
    }

    printf("\n=== SCHEDULING SIMULATION ===\n");

    run_simulation();
}

void run_simulation() {
    // Reset doctor for new simulation
    initialiseDoctor(&global_doctor, global_doctor.name);
    
    // Reset all patients
    PatientNode* current = global_patient_list->head;
    while (current) {
        resetPatientScheduling(current->patient);
        current = current->next;
    }

    printf("\nStarting simulation with %d patients...\n", global_patient_list->count);
    printf("Doctor's schedule: %s to %s (Break: %s to %s)\n",
           minutesToTime(global_doctor.startTime), minutesToTime(global_doctor.endTime),
           minutesToTime(global_doctor.breakStart), minutesToTime(global_doctor.breakEnd));

    clock_t start = clock();
    
    printf("\n--- Running Hybrid Scheduler ---\n");
    SectionedWaitingList* sectionedList = divideByDynamicPriority(global_patient_list, 0);
    if (sectionedList) {
        runHybridScheduler(sectionedList, &global_doctor);
        freeSectionedList(sectionedList);
    }
    
    clock_t end = clock();
    double simulationTime = ((double)(end - start)) / CLOCKS_PER_SEC;

    printf("\nSimulation completed in %.2f seconds\n", simulationTime);
    printf("Real time simulated: %s to %s\n", 
           minutesToTime(global_doctor.startTime), 
           minutesToTime(global_doctor.currentTime));
}

void display_statistics() {
    if (global_patient_list->count == 0) {
        printf("No patients to display statistics for!\n");
        return;
    }

    printf("\n=== SCHEDULING STATISTICS ===\n");
    
    QueueData stats;
    calculateLinkedListStatistics(global_patient_list, &stats);
    
    printf("Patient Distribution:\n");
    printf("- Total Patients: %d\n", stats.numPatient);
    printf("- Urgent Cases: %d\n", stats.urgentCount);
    printf("- Appointments: %d (Late: %d)\n", stats.appointmentCount, stats.lateAppointments);
    printf("- Walk-ins: %d (Promoted: %d)\n", stats.walkinCount, stats.promotedWalkins);
    printf("- Maximum Waiting Time: %d minutes\n", stats.maxWaitingTime);
    printf("- Maximum Walk-in Waiting: %d minutes\n", stats.maxWalkinWaiting);
    
    // Calculate averages
    int totalWaiting = 0;
    int totalTurnaround = 0;
    int completedPatients = 0;
    
    PatientNode* current = global_patient_list->head;
    while (current) {
        if (current->patient->state == COMPLETED) {
            totalWaiting += current->patient->waitingTime;
            totalTurnaround += current->patient->turnaroundTime;
            completedPatients++;
        }
        current = current->next;
    }
    
    if (completedPatients > 0) {
        printf("\nPerformance Metrics:\n");
        printf("- Average Waiting Time: %.2f minutes\n", (float)totalWaiting / completedPatients);
        printf("- Average Turnaround Time: %.2f minutes\n", (float)totalTurnaround / completedPatients);
        
        // Doctor utilization
        int totalTime = global_doctor.currentTime - global_doctor.startTime;
        if (totalTime > 0) {
            float utilization = (global_doctor.totalConsultationTime * 100.0) / totalTime;
            printf("- Doctor Utilization: %.2f%%\n", utilization);
        }
    }
    
    printf("\nDoctor Performance:\n");
    printf("- Patients Seen: %d\n", global_doctor.patientsSeen);
    printf("- Urgent Patients: %d\n", global_doctor.urgentPatientsSeen);
    printf("- Breaks Taken: %d\n", global_doctor.breaksTaken);
    printf("- Breaks Skipped: %d\n", global_doctor.breaksSkippedDueToUrgent);
}