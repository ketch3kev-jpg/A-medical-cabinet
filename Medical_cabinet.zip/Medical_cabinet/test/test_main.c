#include "../include/scheduler.h"
#include "../include/patient.h"
#include "../include/doctor.h"
#include <time.h>

// Function prototypes
void createSamplePatients(PatientLinkedList* list);
void displayMenu();
void runSimulation(PatientLinkedList* list, Doctor* doctor);
void displayStatistics(PatientLinkedList* list, Doctor* doctor);
void replanifySchedule(PatientLinkedList* list, Doctor* doctor);

int main() {
    printf("=== MEDICAL CABINET DOCTOR SCHEDULING SYSTEM ===\n");
    printf("=== (Re)Planification Module ===\n\n");

    // Initialize doctor
    Doctor doctor;
    initialiseDoctor(&doctor, "Dr. Smith");
    
    // Create patient waiting list
    PatientLinkedList* patientList = createLinkedList();
    if (!patientList) {
        printf("Error: Could not create patient list!\n");
        return 1;
    }

    int choice;
    do {
        displayMenu();
        printf("Enter your choice: ");
        scanf("%d", &choice);
        
        switch(choice) {
            case 1:
                createSamplePatients(patientList);
                break;
            case 2:
                displayLinkedList(patientList);
                break;
            case 3:
                runSimulation(patientList, &doctor);
                break;
            case 4:
                displayStatistics(patientList, &doctor);
                break;
            case 5:
                replanifySchedule(patientList, &doctor);
                break;
            case 6:
                displayDoctorStatus(&doctor);
                break;
            case 7:
                printf("Exiting system...\n");
                break;
            default:
                printf("Invalid choice! Please try again.\n");
        }
    } while(choice != 7);

    // Cleanup
    freeLinkedList(patientList);
    
    printf("Thank you for using the Medical Cabinet Scheduling System!\n");
    return 0;
}

void createSamplePatients(PatientLinkedList* list) {
    printf("\n=== CREATING SAMPLE PATIENTS ===\n");
    
    // Clear existing list
    PatientNode* current = list->head;
    while (current) {
        PatientNode* next = current->next;
        free(current);
        current = next;
    }
    list->head = NULL;
    list->tail = NULL;
    list->count = 0;

    // Sample patients with realistic times (in minutes from 8:00 AM)
    Patient* patients[10];
    
    // Urgent cases (arrive unexpectedly)
    patients[0] = malloc(sizeof(Patient));
    initialisePatient(patients[0], 1, "John Emergency", URGENT, -1, 30, 15); // Arrives at 8:30
    
    patients[1] = malloc(sizeof(Patient));
    initialisePatient(patients[1], 2, "Maria Critical", URGENT, -1, 120, 20); // Arrives at 10:00
    
    // Appointments (scheduled)
    patients[2] = malloc(sizeof(Patient));
    initialisePatient(patients[2], 3, "Robert Wilson", APPOINTMENT, 60, 55, 25); // 9:00 appointment
    
    patients[3] = malloc(sizeof(Patient));
    initialisePatient(patients[3], 4, "Sarah Johnson", APPOINTMENT, 90, 85, 15); // 9:30 appointment
    
    patients[4] = malloc(sizeof(Patient));
    initialisePatient(patients[4], 5, "Michael Brown", APPOINTMENT, 150, 160, 30); // 10:30 appointment (late)
    
    // Walk-ins
    patients[5] = malloc(sizeof(Patient));
    initialisePatient(patients[5], 6, "Emily Davis", WALKIN, -1, 45, 10); // Arrives at 8:45
    
    patients[6] = malloc(sizeof(Patient));
    initialisePatient(patients[6], 7, "David Miller", WALKIN, -1, 100, 12); // Arrives at 9:40
    
    patients[7] = malloc(sizeof(Patient));
    initialisePatient(patients[7], 8, "Lisa Garcia", WALKIN, -1, 180, 8); // Arrives at 11:00
    
    // Mixed types for testing
    patients[8] = malloc(sizeof(Patient));
    initialisePatient(patients[8], 9, "Thomas Lee", APPOINTMENT, 200, 195, 18); // 11:20 appointment
    
    patients[9] = malloc(sizeof(Patient));
    initialisePatient(patients[9], 10, "Jennifer White", URGENT, -1, 240, 22); // Arrives at 12:00

    // Add to linked list
    for (int i = 0; i < 10; i++) {
        addPatientToLinkedList(list, patients[i]);
    }

    printf("Created 10 sample patients:\n");
    printf("- 3 Urgent cases\n");
    printf("- 4 Appointments (1 late)\n");
    printf("- 3 Walk-ins\n");
}

void displayMenu() {
    printf("\n=== MAIN MENU ===\n");
    printf("1. Create Sample Patients\n");
    printf("2. Display Patient List\n");
    printf("3. Run Scheduling Simulation\n");
    printf("4. Display Statistics\n");
    printf("5. Replanify Schedule\n");
    printf("6. Display Doctor Status\n");
    printf("7. Exit\n");
    printf("=================\n");
}

void runSimulation(PatientLinkedList* list, Doctor* doctor) {
    if (list->count == 0) {
        printf("No patients in the list! Please create patients first.\n");
        return;
    }

    printf("\n=== SCHEDULING SIMULATION ===\n");
    
    int algorithmChoice;
    scanf("%d", &algorithmChoice);

    // Reset doctor for new simulation
    initialiseDoctor(doctor, doctor->name);
    
    // Reset all patients
    PatientNode* current = list->head;
    while (current) {
        resetPatientScheduling(current->patient);
        current = current->next;
    }

    printf("\nStarting simulation with %d patients...\n", list->count);
    printf("Doctor's schedule: %s to %s (Break: %s to %s)\n",
           minutesToTime(doctor->startTime), minutesToTime(doctor->endTime),
           minutesToTime(doctor->breakStart), minutesToTime(doctor->breakEnd));

    clock_t start = clock();

    SectionedWaitingList* sectionedList = divideByDynamicPriority(list, 0);
    if (sectionedList) {
        runHybridScheduler(sectionedList, doctor);
        freeSectionedList(sectionedList);
    }
    
    clock_t end = clock();
    double simulationTime = ((double)(end - start)) / CLOCKS_PER_SEC;

    printf("\nSimulation completed in %.2f seconds\n", simulationTime);
    printf("Real time simulated: %s to %s\n", 
           minutesToTime(doctor->startTime), 
           minutesToTime(doctor->currentTime));
}

void displayStatistics(PatientLinkedList* list, Doctor* doctor) {
    if (list->count == 0) {
        printf("No patients to display statistics for!\n");
        return;
    }

    printf("\n=== SCHEDULING STATISTICS ===\n");
    
    QueueData stats;
    calculateLinkedListStatistics(list, &stats);
    
    printf("Patient Distribution:\n");
    printf("- Total Patients: %d\n", stats.numPatient);
    printf("- Urgent Cases: %d\n", stats.urgentCount);
    printf("- Appointments: %d (Late: %d)\n", stats.appointmentCount, stats.lateAppointments);
    printf("- Walk-ins: %d (Promoted: %d)\n", stats.walkinCount, stats.promotedWalkins);
    printf("- Maximum Waiting Time: %d minutes\n", stats.maxWaitingTime);
    printf("- Maximum Walk-in Waiting: %d minutes\n", stats.maxWalkinWaiting);
    
    // Calculate averages
    int totalWaiting = 0;
    int totalTurnaround = 0;
    int completedPatients = 0;
    
    PatientNode* current = list->head;
    while (current) {
        if (current->patient->state == COMPLETED) {
            totalWaiting += current->patient->waitingTime;
            totalTurnaround += current->patient->turnaroundTime;
            completedPatients++;
        }
        current = current->next;
    }
    
    if (completedPatients > 0) {
        printf("\nPerformance Metrics:\n");
        printf("- Average Waiting Time: %.2f minutes\n", (float)totalWaiting / completedPatients);
        printf("- Average Turnaround Time: %.2f minutes\n", (float)totalTurnaround / completedPatients);
        printf("- Doctor Utilization: %.2f%%\n", 
               (doctor->totalConsultationTime * 100.0) / (doctor->currentTime - doctor->startTime));
    }
    
    printf("\nDoctor Performance:\n");
    printf("- Patients Seen: %d\n", doctor->patientsSeen);
    printf("- Urgent Patients: %d\n", doctor->urgentPatientsSeen);
    printf("- Breaks Taken: %d\n", doctor->breaksTaken);
    printf("- Breaks Skipped: %d\n", doctor->breaksSkippedDueToUrgent);
}

void replanifySchedule(PatientLinkedList* list, Doctor* doctor) {
    if (list->count == 0) {
        printf("No patients to replanify!\n");
        return;
    }

    printf("\n=== SCHEDULE REPLANIFICATION ===\n");
    
    int currentTime = doctor->currentTime;
    printf("Current time: %s\n", minutesToTime(currentTime));
    
    // Check for walk-in promotions
    int promotedIds[100];
    int promotionCount = getPromotionPredictions(list, currentTime, promotedIds, 100);
    
    if (promotionCount > 0) {
        printf("Walk-in promotions predicted:\n");
        for (int i = 0; i < promotionCount; i++) {
            Patient* p = findPatientInLinkedList(list, promotedIds[i]);
            if (p) {
                printf("- %s (ID: %d) waiting for %d minutes\n", 
                       p->name, p->id, currentTime - p->arrivalTime);
            }
        }
    }
    
    // Display current priorities
    printf("\nCurrent Patient Priorities:\n");
    displayPatientPriorities(list, currentTime);
    
    // Create new sectioned list based on current state
    SectionedWaitingList* newSectionedList = divideByDynamicPriority(list, currentTime);
    if (newSectionedList) {
        printf("\nProposed New Schedule Organization:\n");
        displaySectionedList(newSectionedList);
        
        char response;
        printf("\nApply this replanification? (y/n): ");
        scanf(" %c", &response);
        
        if (response == 'y' || response == 'Y') {
            printf("Applying replanification...\n");
            
            // Reset only waiting patients for rescheduling
            PatientNode* current = list->head;
            while (current) {
                if (current->patient->state == WAITING) {
                    resetPatientScheduling(current->patient);
                }
                current = current->next;
            }
            
            runHybridScheduler(newSectionedList, doctor);
            printf("Replanification completed!\n");
        }
        
        freeSectionedList(newSectionedList);
    }
}

// Additional utility function to handle patient arrivals during simulation
void simulateRealTimeArrivals(PatientLinkedList* list, int currentTime) {
    // This function could be used to simulate new patients arriving during the day
    static int nextPatientId = 11;
    
    // 20% chance of new urgent patient every 30 minutes
    if (rand() % 5 == 0 && currentTime % 30 == 0) {
        Patient* newUrgent = malloc(sizeof(Patient));
        char name[40];
        snprintf(name, sizeof(name), "Emergency %d", nextPatientId);
        initialisePatient(newUrgent, nextPatientId++, name, URGENT, -1, currentTime, 10 + rand() % 20);
        addPatientToLinkedList(list, newUrgent);
        printf("  -> NEW ARRIVAL: %s (Urgent) at %s\n", name, minutesToTime(currentTime));
    }
    
    // 10% chance of new walk-in every 15 minutes
    if (rand() % 10 == 0 && currentTime % 15 == 0) {
        Patient* newWalkin = malloc(sizeof(Patient));
        char name[40];
        snprintf(name, sizeof(name), "Walkin %d", nextPatientId);
        initialisePatient(newWalkin, nextPatientId++, name, WALKIN, -1, currentTime, 5 + rand() % 15);
        addPatientToLinkedList(list, newWalkin);
        printf("  -> NEW ARRIVAL: %s (Walk-in) at %s\n", name, minutesToTime(currentTime));
    }
}