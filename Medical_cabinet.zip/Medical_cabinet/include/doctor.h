//This is our critical resource
#ifndef DOCTOR_H
#define DOCTOR_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

//the doctor's state/info
typedef struct{
    char name[40];

    int startTime;// time for the start of consultations
    int endTime;
    int breakStart;
    int breakEnd;

    int gapBetweenPatients;//I assumed it is 1 min
    int isOnBreak;

    int currentTime;
    int patientsSeen;
    int totalConsultationTime;

    int isWithUrgentPatient;//a sort of boolean

    int urgentPatientsSeen;
    int breaksTaken;
    int breaksSkippedDueToUrgent;
} Doctor;

void initialiseDoctor(Doctor* doctor, const char* name);
void setDoctorSchedule(Doctor* doctor, int startHour, int startMinute, 
                      int endHour, int endMinute, int breakStartHour, 
                      int breakStartMinute, int breakDuration);
int isDoctorAvailable(const Doctor* doctor, int currentTime);
int getNextAvailableTime(Doctor* doctor, int currentTime, int isUrgentCase);
void updateDoctorTime(Doctor* doctor, int consultationTime, int isUrgentCase);
void checkAndTakeBreak(Doctor* doctor, int currentTime);
void displayDoctorStatus(const Doctor* doctor);

int timeToMinutes(int hours, int minutes);
char* minutesToTime(int minutes);

#endif