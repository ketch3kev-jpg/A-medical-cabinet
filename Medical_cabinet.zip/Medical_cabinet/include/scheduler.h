#ifndef SCHEDULER_H
#define SCHEDULER_H

#include "../include/patient.h"
#include "../include/doctor.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define TIME_QUANTUM 5

typedef struct {
    int numPatient;
    int walkinCount;
    int appointmentCount;
    int urgentCount;
    int lateAppointments;
    int promotedWalkins;
    int maxWaitingTime;
    int maxWalkinWaiting;
} QueueData;

typedef struct PatientNode {
    Patient* patient;
    struct PatientNode* next;
} PatientNode;

typedef struct {
    PatientNode* head;
    PatientNode* tail;
    int count;
} PatientLinkedList;

typedef struct {
    int type;
    int count;
    Patient** patients;
} PrioritySection;

typedef struct {
    PrioritySection* sections;
    int sectionCount;
    int totalPatients;
} SectionedWaitingList;

typedef struct {
    Patient** patients;
    int count;
    int currentIndex;
    int lastServedTime;
} RRGroup;

// Basic scheduling algorithms
void runFCFS(PatientLinkedList* list, Doctor* doctor);
void runSJF(PatientLinkedList* list, Doctor* doctor);
void runRoundRobin(PatientLinkedList* list, Doctor* doctor);
void runPriorityScheduling(PatientLinkedList* list, Doctor* doctor);

// Section-based scheduling algorithms
void runFCFS_section(PatientLinkedList* list, Doctor* doctor, int start_index, int end_index);
void runSJF_section(PatientLinkedList* list, Doctor* doctor, int start_index, int end_index);
void runRoundRobin_section(PatientLinkedList* list, Doctor* doctor, int start_index, int end_index);
void runPriorityScheduling_section(PatientLinkedList* list, Doctor* doctor, int start_index, int end_index);

// Linked List Management
PatientLinkedList* createLinkedList();
void freeLinkedList(PatientLinkedList* list);
void addPatientToLinkedList(PatientLinkedList* list, Patient* patient);
void insertPatientAtPosition(PatientLinkedList* list, Patient* patient, int position);
void insertPatientSorted(PatientLinkedList* list, Patient* patient, int (*compareFunc)(const Patient*, const Patient*));
void removePatientFromLinkedList(PatientLinkedList* list, int patientId);
Patient* findPatientInLinkedList(const PatientLinkedList* list, int patientId);
Patient* getPatientAtPosition(const PatientLinkedList* list, int position);
void displayLinkedList(const PatientLinkedList* list);

// Comparison functions
int compareByArrivalTime(const Patient* a, const Patient* b);
int compareByConsultationTime(const Patient* a, const Patient* b);
int compareByDynamicPriority(const Patient* a, const Patient* b, int currentTime);

// Priority calculation
double calculatePatientPriority(const Patient* patient, int currentTime);
void displayPatientPriorities(const PatientLinkedList* list, int currentTime);

// Section division and hybrid scheduling
SectionedWaitingList* divideByDynamicPriority(PatientLinkedList* list, int currentTime);
void freeSectionedList(SectionedWaitingList* sectionedList);
void displaySectionedList(const SectionedWaitingList* sectionedList);
void runHybridScheduler(SectionedWaitingList* sectionedList, Doctor* doctor);

// Statistics
void calculateLinkedListStatistics(const PatientLinkedList* list, QueueData* stats);
void displayLinkedListStatus(const PatientLinkedList* list, int currentTime);
int getPromotionPredictions(const PatientLinkedList* list, int currentTime, int* promotedIds, int maxPromotions);

#endif