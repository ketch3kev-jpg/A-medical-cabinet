#ifndef PATIENT_H
#define PATIENT_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

//declaring my levels of priorities(patient types)
//here the numbers show the levels of priority
typedef enum{
    URGENT = 3,
    APPOINTMENT = 2,
    WALKIN = 1
}AppointmentType;

//Patient states
typedef enum{
    WAITING,
    PROMOTED,
    IN_CONSULTATION,
    COMPLETED,
    CANCELED
}PState;//PState for patient's state

//Patient's data
typedef struct{
    int id;
    char name[40];

    AppointmentType type;

    //different times parameters
    //time in minutes
    int scheduledTime;
    int arrivalTime;
    int consultationTime;
    int remainingTime;//remaining time to complete de consultation

    //other parameters(results from schedulng)
    PState state;
    int startTime;
    int endTime;
    int waitingTime;
    int turnaroundTime;

    //For my dear urgent cases
    int urgencyLevel;// this is to distinguish urgencies on a scale of 1 to 10
    
    //Additions
    int hasArrived;//some sort of boolean(0 for no arrival)
    AppointmentType originalType;
    int promotionTime;
}Patient;

//Utility function
char* patientTypeToString(AppointmentType type);
char* PStateToString(PState state);
AppointmentType stringToPatientType(const char* typeStr);
char* patientTimeToString(int minutes);

//Management function
void initialisePatient(Patient* patient, int id, const char* name,
        AppointmentType type, int scheduledTime, int arrivalTime, int consulationTime);
void resetPatientScheduling(Patient* patient);
int isPatientLate(const Patient* patient);

//Walk-in special
int shouldPromoteWalkin(const Patient* patient, int currentTime);
void promoteWalkin(Patient* patient, int currentTime);
int getWalkinWaitingTime(const Patient* patient, int currentTime);

//Displaying patient's info
void displayPatientInfo(const Patient* patient);

#endif